# CVR 3.2 — Diagnostic Foundation / AAPL Causal-Candidate Pilot

This package is the current computational baseline for the CVR 3.2 architecture. It preserves the working CVR 3.0 causal-candidate machinery while adding the diagnostic history layer required before genuine OOR can be invoked.


## CVR 3.2 diagnostic layer

The new `cvr30.diagnostic` module implements the first CVR 3.2 layer:

```text
model generations
      |
      v
error signatures
      |
      v
error trajectories + accommodation history
      |
      +--> domain-of-adequacy profile
      |
      v
ordinary / corrigible / recurrent / persistent-blind-spot status
```

This layer deliberately **does not declare OOR or generate `Z_D`**. A persistent blind spot is a pre-OOR diagnostic state. The intended later sequence is:

```text
persistent blind spot
        |
        v
     OOR gate
        |
        v
      Z_D generation
```

The diagnostic tests currently cover ordinary error, successful accommodation, recurrent error with continuing improvement, diminishing returns with a persistent blind spot, and a false structural alarm when the residual is not established as limiting.

An important safeguard is that diminishing returns and persistence are tracked separately: neither one alone is sufficient for OOR.

## Scope

CVR 3.0 is a **causal-candidate testing framework**, not a causal-discovery
oracle. The pilot was built around the hypothesis:

> `Z_D = pre-event expectation revision / expectation-state revision`

The implementation deliberately does **not** promote that hypothesis to a
canonical causal fact. The output is a status such as:

- `SUPPORTED_CANDIDATE`
- `MODERATE_PROVISIONAL`
- `INCONCLUSIVE`
- `REJECTED_CANDIDATE`
- `INSUFFICIENT_DATA`

The framework keeps prediction error, model ablation, necessity, transfer,
and rival comparison conceptually separate.

## Architecture

```text
raw evidence
    |
    v
measurement / benchmark validation
    |
    v
frozen W0 episode
    |
    +---- baseline M0
    |
    +---- enriched M1(Z_D)
    |
    +---- do(not Z_D) ablation
    |
    +---- counterfactual necessity tests
    |
    +---- cross-instance stability
    |
    +---- rival candidates
    |
    v
causal-status gate
    |
    v
revision / survivor record
```

The package also contains a lightweight epistemic-accessibility layer. It is
used for admissibility and model-space bookkeeping; it does not manufacture
causal identification.

## Leakage rule

Anything timestamped after the frozen W0 boundary is excluded from the
candidate's explanatory inputs. The realized outcome is allowed only at the
evaluation stage.

## Important limitation

The AAPL pilot's substantive empirical conclusion remains provisional. The
code can test the structure given appropriate point-in-time data; it cannot
create missing analyst-revision histories. In particular, an event-time
consensus number is not silently treated as a reconstructed pre-event
revision path.

## Run

```bash
python -m cvr30.demo
```

Run tests with:

```bash
python -m unittest discover -s tests -v
```

No external packages are required.

## Changelog: 2026-09-29 revision

Three changes made this session, in order:

1. **Fixed a real bug in `demo.py`.** It fed post-event evidence into the
   pre-event evidence list, which its own W0-leakage guard correctly
   rejected -- the demo shipped broken. Fixed by keeping post-event data
   only in `Outcome`, where it belongs.

2. **Replaced `gate.py`'s nested boolean-threshold decision tree with a
   graded score.** The prior `causal_status_gate` combined
   `ablation.improves_fit`, `necessity_rate >= threshold`, and
   `stability.stable_sign` via ANDed boolean checks into a status with a
   *hardcoded* constant score per branch (0.85 / 0.65 / 0.25 / 0.20) --
   functionally the same shape as the `necessary = improvement > tolerance`
   rule this project explicitly retired, just moved up a level. When a
   `DiscriminationResult` is supplied (see below), the gate now derives a
   continuous score from LR+ via a log transform, and lets discrimination
   veto a status that necessity/ablation/stability alone would have
   supported (or raise the ceiling on one they'd only weakly support) --
   rather than letting three booleans alone decide the category. Calling
   the gate without `discrimination` preserves the old behavior exactly,
   so no existing caller breaks.

3. **Added `discrimination.py`: the population-level Law-of-Likelihood test
   that was missing entirely.** `necessity.py`'s existing test only checks
   classical necessity (does the outcome fail when the candidate is
   removed, within one case); it never checked whether the candidate
   condition is actually *specific* to the cause across a population --
   the fever/measles distinction the project's conceptual work was built
   around. New in this module: `discriminate()` computes sensitivity,
   specificity, LR+, and Youden's J from an explicit cause/negative-control
   population split, with Wilson score intervals (not the normal
   approximation, which misbehaves at n=4-ish samples) and a `well_powered`
   flag that compresses the gate's score toward 0.5 when either population
   is small, rather than reporting false precision. `build_reference_population()`
   makes the reference-class split an explicit, named, caller-supplied
   choice -- never an implicit default -- and turns the panel's existing
   non-contradiction events into a negative-control population for free
   once the right boolean fields are named on the rows, rather than
   requiring them to be hand-assembled.

Still open (not addressed this session -- see the project's
`necessary-condition-schema` notes for the full list): a concrete
reference-class *selection* procedure (vs. just a split, which is now
implemented); an explicit stopping rule for Z_D-unification across several
necessary conditions; wiring confidence-interval width into the
survivor-formula (`F_tau^S`) lifecycle across walk-forward episodes; and
running any of this on the actual AAPL/BWXT panel data rather than
synthetic illustrations, which needs the real spreadsheet columns for all
19 AAPL events, not just the 4 flagged contradictions.

## Model-generation history

`cvr30.diagnostic.ModelHistory` now provides the stateful bridge from completed
CVR model generations to the diagnostic layer. It enforces a contiguous parent
lineage, retains adequacy and improvement trajectories, discovers observed
error families, builds their trajectories, and can assess all observed families
without invoking OOR.

The history object records **completed** generations only. It does not mutate a
live model, infer hindsight revisions, declare OOR, or generate `Z_D`.

The intended next integration is to have the existing revision/evaluation path
record each completed generation into `ModelHistory`, so diagnostic state is
accumulated automatically during actual CVR model evolution.

## Revision/evaluation orchestrator

`cvr30.orchestrator.RevisionOrchestrator` implements the explicit revision
loop:

```text
M_t -> prediction -> DOOR diagnosis -> accommodation
     -> prospective evaluation -> record generation -> M_{t+1}
```

The orchestrator is a thin coordinator with injected callables for the
scientific decisions:

- **DiagnosticClassifier** — classifies prediction residuals structurally
  (error kind, location, context/relational/structural features).
- **AccommodationPolicy** — decides what accommodation records to attach.
- **ProspectiveEvaluator** — scores the current model's adequacy on the
  completed episodes (model-level, caller-supplied).
- **SurvivorConstructor** — constructs the next model M_{t+1}.

The orchestrator produces predictions from the current model using only frozen
W0 evidence, diagnoses residuals via `error_signature_from_episode`, evaluates
adequacy, and records the completed generation into `ModelHistory` via
`record_generation`. The next model is constructed from the cycle's outputs but
is not itself recorded — its predictions will be evaluated in the next cycle.

The OOR gate and Z_D generation remain deliberately downstream. The orchestrator
does not import or invoke `cvr30.oor`, `cvr30.gate`, or `cvr30.pilot`.

A `RevisionCycleResult` captures the boundary outputs: current model ID, next
model, predicted episodes, diagnosed errors, accommodations, adequacy score,
and the recorded `ModelGeneration`.

## OOR gate

`cvr30.oor` now provides a trajectory-level OOR gate that sits downstream of
the diagnostic layer.  The existing episode-level functions (`diagnose`,
`is_candidate_oor`, `OORObservation`) are preserved for backward compatibility.

The gate consumes a `DiagnosticAssessment` (from `ModelHistory.assess()`) and
an independent constraint supplied by the caller:

```text
ModelHistory.assess()
    -> DiagnosticAssessment (eligible_for_oor_review)
    -> OOR gate (review_trajectory_for_oor)
    -> OORGateResult
        |
        +--> eligible_for_zd_generation = True/False
```
`OORGateStatus` encodes the gate's decision:

- `NOT_REVIEWABLE` — the trajectory has not reached a persistent blind spot.
- `INDEPENDENT_CONSTRAINT_REQUIRED` — a persistent blind spot was diagnosed,
  but no independent constraint corroborates it.
- `NOT_OOR` — the residual was driven to zero or persistence is below
  threshold despite the diagnostic state and constraint.
- `CANDIDATE_OOR` — all conditions met; eligible for future Z_D generation.

The gate does not generate `Z_D`.  `OORGateResult.eligible_for_zd_generation`
is the handoff point for a future Z_D generation step.

`review_history_for_oor()` is a convenience wrapper that applies the gate to
every trajectory in a `ModelHistory`, using per-signature independent
constraints.  This is the natural downstream consumer of `ModelHistory.assess()`.

## Z_D candidate generation

`cvr30.zd_generation` implements the final step in the CVR 3.2 diagnostic chain:

```text
ModelHistory / OORGateResult
    -> Z_D candidate specification
    -> future causal-candidate testing (ablation, necessity, etc.)
```

When the OOR gate has declared a candidate OOR
(`eligible_for_zd_generation` is True), `generate_zd_candidate()` produces a
`ZDCandidateSpec` describing the proposed explanatory variable.

This is **candidate generation**, not causal discovery.  The generated
specification is explicitly unvalidated:

- It does not claim any `CausalStatus`.
- It does not contain a `CandidateResult`.
- It does not run the causal-status gate or the pilot.
- It does not promote `Z_D` to truth.

The spec carries:

- `candidate_id` (defaults to `"Z_D"`) for consumption by the existing
  causal-candidate testing pipeline.
- `required_measurements` — the measurements needed to construct the
  variable (pre-event expectation, prior baseline, W0 boundary timestamp,
  realized outcome for evaluation only).
- `validation_plan` — the existing tests (ablation, necessity, stability,
  discrimination, causal-status gate) listed as a plan, not executed.
- `source_signature` and `source_constraint_id` — provenance from the OOR gate
  result that opened the door.

`generate_zd_candidate_with_strategy()` allows callers to inject a custom
proposal strategy for non-default Z_D candidates.  `pilot_candidate_id()` is a
small helper that extracts the candidate ID for use with
`run_candidate_pilot()` without invoking the pilot.

## Autonomous revision loop

`cvr30.loop.RevisionLoop` is the top-level coordinator that wires the entire
CVR 3.2 chain into a single autonomous pipeline:

```text
M_t -> orchestrator.run_cycle() -> M_{t+1}
    -> ModelHistory.assess()
    -> review_history_for_oor()
    -> generate_zd_candidate()
    -> stop or continue
```

The loop runs orchestrator cycles, uses each cycle's next model as the next
cycle's current model, and after enough cycles have accumulated, checks the
diagnostic state.  When a persistent blind spot emerges and the OOR gate
opens, a Z_D candidate is generated and the loop stops.

The loop is configured with injected policies:

- **EpisodeProvider** — produces episodes per cycle (fixed or batched).
- **DominancePolicy** — identifies dominant error families for assessment.
- **IndependentConstraintProvider** — supplies independent constraints for the
  OOR gate.

Stop conditions (checked in order):

1. **Z_D candidate generated** — persistent blind spot + independent constraint
   + non-zero residual + sufficient persistence.
2. **OOR constraint required** — persistent blind spot diagnosed but no
   independent constraint was supplied.
3. **Adequacy plateau** — adequacy improvement has been at or below threshold
   for `plateau_window` cycles without a blind spot.
4. **Max cycles reached** — `max_cycles` exhausted.
5. **No episodes** — episode provider returned empty.

The loop does not feed a generated `ZDCandidateSpec` back into the model.
Testing and incorporating Z_D belongs to a later step that uses real candidate
evidence and `run_candidate_pilot()`.
