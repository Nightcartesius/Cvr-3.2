"""CVR 3.2: Corrigible Veridical Realism diagnostic pilot."""

__version__ = "3.2.0-alpha1"
