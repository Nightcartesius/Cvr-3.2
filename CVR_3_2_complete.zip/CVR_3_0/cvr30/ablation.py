from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Mapping, Sequence

from .models import rmse


@dataclass(frozen=True)
class AblationResult:
    candidate_id: str
    full_error: float
    ablated_error: float
    delta_error: float
    improves_fit: bool
    interpretation: str


def do_not_candidate(
    row: Mapping[str, float],
    candidate_id: str,
) -> dict[str, float]:
    """Model intervention: remove candidate information, rather than merely
    deleting the observed outcome after the fact."""
    result = dict(row)
    result[candidate_id] = 0.0
    return result


def ablate(
    candidate_id: str,
    rows: Sequence[Mapping[str, float]],
    actual: Sequence[float],
    full_predict: Callable[[Mapping[str, float]], float],
    ablated_predict: Callable[[Mapping[str, float]], float],
) -> AblationResult:
    if len(rows) != len(actual):
        raise ValueError("rows and actual must have equal length")
    full = [full_predict(r) for r in rows]
    ablated = [ablated_predict(do_not_candidate(r, candidate_id)) for r in rows]
    e_full = rmse(full, actual)
    e_ab = rmse(ablated, actual)
    delta = e_ab - e_full
    return AblationResult(
        candidate_id=candidate_id,
        full_error=e_full,
        ablated_error=e_ab,
        delta_error=delta,
        improves_fit=e_full < e_ab,
        interpretation=(
            "Ablation improves fit relative to the candidate-free model."
            if e_full < e_ab
            else "Ablation does not establish dependence on the candidate."
        ),
    )
