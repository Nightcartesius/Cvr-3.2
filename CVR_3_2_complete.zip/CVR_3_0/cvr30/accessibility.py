from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Mapping


@dataclass(frozen=True)
class World:
    world_id: str
    state: Mapping[str, Any]
    constraints: frozenset[str] = frozenset()
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass
class AccessibilityFrame:
    worlds: dict[str, World] = field(default_factory=dict)
    edges: dict[str, set[str]] = field(default_factory=dict)

    def add_world(self, world: World) -> None:
        self.worlds[world.world_id] = world
        self.edges.setdefault(world.world_id, set())

    def connect(self, source: str, target: str) -> None:
        if source not in self.worlds or target not in self.worlds:
            raise KeyError("both worlds must be registered before connecting")
        self.edges.setdefault(source, set()).add(target)

    def accessible_from(self, source: str) -> tuple[World, ...]:
        return tuple(self.worlds[w] for w in sorted(self.edges.get(source, set())))

    def admissible(
        self,
        world_id: str,
        proposition: Callable[[Mapping[str, Any]], bool],
    ) -> bool:
        return proposition(self.worlds[world_id].state)


def invariant_across(
    worlds: Iterable[World],
    proposition: Callable[[Mapping[str, Any]], bool],
) -> bool:
    worlds = list(worlds)
    return bool(worlds) and all(proposition(w.state) for w in worlds)


def epistemic_invariance(
    worlds: Iterable[World],
    proposition: Callable[[Mapping[str, Any]], bool],
) -> float:
    worlds = list(worlds)
    if not worlds:
        return 0.0
    return sum(bool(proposition(w.state)) for w in worlds) / len(worlds)
