from datetime import datetime, timezone

from .accessibility import AccessibilityFrame, World, epistemic_invariance
from .discrimination import discriminate
from .episode import EarningsEpisode
from .gate import GateThresholds
from .models import LinearModel
from .pilot import run_candidate_pilot
from .provenance import assert_no_future_leakage
from .types import Evidence, Provenance, EvidenceStatus, Outcome


def main() -> None:
    # Small synthetic demonstration only. It is not an empirical AAPL result.
    t0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
    post = datetime(2026, 1, 2, tzinfo=timezone.utc)

    # Only pre-event evidence belongs in the episode's evidence list. The
    # realized post-event outcome is carried separately via `Outcome`, below
    # -- putting it here as well is exactly the W0 leakage the guard exists
    # to catch (this was a bug in the original demo: it tripped its own
    # leakage assertion).
    evidence = [
        Evidence(
            "expectation_revision",
            1.0,
            Provenance("demo_pre_event", t0, status=EvidenceStatus.OBSERVED),
        ),
    ]

    episode = EarningsEpisode(
        "DEMO-001",
        "AAPL",
        t0,
        t0,
        evidence,
        Outcome("DEMO-001", -0.02, "abnormal_next_session_return", post, 0.0),
    )

    assert_no_future_leakage(episode.evidence, episode.w0_boundary)
    row = episode.feature_dict()

    full = LinearModel("M1", ("expectation_revision",), -0.01, (-0.01,))
    baseline = LinearModel("M0", ("expectation_revision",), -0.01, (0.0,))

    rows = [
        {"expectation_revision": 1.0},
        {"expectation_revision": 0.8},
        {"expectation_revision": 1.2},
        {"expectation_revision": 0.9},
    ]
    actual = [-0.02, -0.018, -0.021, -0.019]

    worlds = [
        {"expectation_revision": 1.0, "resolution": 1.0},
        {"expectation_revision": 0.8, "resolution": 1.0},
        {"expectation_revision": 1.2, "resolution": 1.0},
        {"expectation_revision": 0.9, "resolution": 1.0},
    ]

    report = run_candidate_pilot(
        "expectation_revision",
        rows,
        actual,
        full,
        baseline,
        worlds,
        lambda w: bool(w.get("resolution", 0.0)),
        rival_effects={"eps_surprise": [0.01, -0.02, 0.01, -0.01]},
        thresholds=GateThresholds(min_instances=3),
    )

    frame = AccessibilityFrame()
    frame.add_world(World("W0", row))
    frame.add_world(World("W1", {"expectation_revision": 1.0}))
    frame.connect("W0", "W1")

    print("CVR 3.0 demo")
    print("candidate:", report.candidate.candidate_id)
    print("status:", report.candidate.status.value)
    print("score:", report.candidate.score)
    print("reasons:", *report.candidate.reasons, sep="\n  - ")
    print("epistemic invariance:",
          epistemic_invariance(frame.accessible_from("W0"),
                               lambda s: s.get("expectation_revision") == 1.0))


def discrimination_demo() -> None:
    """Illustrates the population-level discrimination test on two
    synthetic populations shaped like the fever/measles vs. Koplik-spots
    contrast from the project's conceptual work. These numbers are
    illustrative only -- NOT the real AAPL/BWXT panel, which would require
    the candidate-condition value for all 19 events (only the 4 flagged
    contradictions have that data quoted in the project's transfer
    documents; the other 15 would need to come from the actual panel file
    before a real discrimination test could be run on them).
    """
    print("\n--- discrimination demo (synthetic) ---")

    fever = discriminate(
        candidate_id="fever",
        reference_class="measles_cases_vs_general_clinic_population",
        cause_population=[True, True, True, True, True],
        control_population=[True, False, True, True, False, True, False, True],
    )
    print(f"fever: LR+={fever.likelihood_ratio_positive}, {fever.interpretation}")

    koplik = discriminate(
        candidate_id="koplik_spots",
        reference_class="measles_cases_vs_general_clinic_population",
        cause_population=[True, True, True, True, False],
        control_population=[False] * 20,
    )
    print(f"koplik_spots: LR+={koplik.likelihood_ratio_positive}, {koplik.interpretation}")

    print(
        "\nNote: koplik_spots' LR+ is reported as None (undefined), not "
        "infinite -- zero hits in a 20-case control sample is provisional "
        "evidence of a strong discriminator, not proof of a perfect one."
    )


if __name__ == "__main__":
    main()
    discrimination_demo()
