"""CVR 3.2 diagnostic state and error-trajectory machinery.

This module deliberately stops short of declaring OOR or generating Z_D.  Its
job is to preserve model-generation history so that later OOR decisions can
be grounded in demonstrated corrigibility, persistence, and limiting error.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Iterable, Mapping, Optional, Sequence

from .episode import EarningsEpisode
from .types import ErrorKind


class DiagnosticStatus(str, Enum):
    """History-dependent status of an error family.

    These are diagnostic states, not causal verdicts.  In particular,
    PERSISTENT_BLIND_SPOT is not itself OOR.
    """

    ORDINARY_ERROR = "ordinary_error"
    CORRIGIBLE_ERROR = "corrigible_error"
    RECURRENT_ERROR = "recurrent_error"
    PERSISTENT_BLIND_SPOT = "persistent_blind_spot"


@dataclass(frozen=True)
class ErrorSignature:
    """A comparison-friendly description of an error pattern.

    Magnitude is intentionally excluded from structural identity.  A residual
    can change size across generations while remaining the same relevant error
    family.  Context/relations/structure are represented by sorted tuples so
    signatures remain immutable and deterministic.
    """

    kind: ErrorKind
    target: str
    location: str = ""
    direction: int = 0
    context_features: tuple[str, ...] = ()
    relational_features: tuple[str, ...] = ()
    structural_features: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if self.direction not in (-1, 0, 1):
            raise ValueError("direction must be -1, 0, or 1")
        object.__setattr__(self, "context_features", tuple(sorted(self.context_features)))
        object.__setattr__(self, "relational_features", tuple(sorted(self.relational_features)))
        object.__setattr__(self, "structural_features", tuple(sorted(self.structural_features)))

    @property
    def family_key(self) -> tuple:
        """Exact structural identity used for trajectory grouping."""
        return (
            self.kind,
            self.target,
            self.location,
            self.direction,
            self.context_features,
            self.relational_features,
            self.structural_features,
        )

    def is_similar_to(
        self,
        other: "ErrorSignature",
        *,
        min_shared_features: int = 1,
        ignore_direction: bool = False,
    ) -> bool:
        """Return whether two errors plausibly belong to the same family.

        Exact family matching is preferred.  Otherwise the method permits a
        controlled partial match, useful when a model revision changes one
        contextual or structural descriptor while the target and error kind
        remain stable.
        """
        if not isinstance(other, ErrorSignature):
            return False
        if self.kind != other.kind or self.target != other.target:
            return False
        if self.location != other.location:
            return False
        if not ignore_direction and self.direction and other.direction:
            if self.direction != other.direction:
                return False

        a = set(self.context_features) | set(self.relational_features) | set(self.structural_features)
        b = set(other.context_features) | set(other.relational_features) | set(other.structural_features)
        if not a or not b:
            return True
        return len(a & b) >= min_shared_features


@dataclass(frozen=True)
class AccommodationRecord:
    """A revision attempt made in response to an error signature."""

    generation_id: str
    signature: ErrorSignature
    accommodation_type: str
    prospective_improvement: Optional[float] = None
    heldout_improvement: Optional[float] = None
    transfer_score: Optional[float] = None
    changed_components: tuple[str, ...] = ()
    status: str = "inconclusive"
    notes: str = ""

    def __post_init__(self) -> None:
        if self.prospective_improvement is not None and not isinstance(
            self.prospective_improvement, (int, float)
        ):
            raise TypeError("prospective_improvement must be numeric or None")
        object.__setattr__(self, "changed_components", tuple(sorted(self.changed_components)))

    @property
    def improved(self) -> bool:
        """Whether this accommodation demonstrated prospective improvement."""
        return bool(
            self.prospective_improvement is not None
            and self.prospective_improvement > 0
        )

    @property
    def transferred(self) -> bool:
        """Whether independent/held-out evidence shows positive reach."""
        value = self.heldout_improvement
        if value is None:
            value = self.transfer_score
        return bool(value is not None and value > 0)


@dataclass(frozen=True)
class ModelGeneration:
    """A completed model state in the diagnostic history."""

    model_id: str
    parent_model_id: Optional[str]
    adequacy_score: float
    errors: tuple[tuple[ErrorSignature, float], ...] = ()
    accommodations: tuple[AccommodationRecord, ...] = ()
    metadata: dict = field(default_factory=dict, compare=False, repr=False)

    def __post_init__(self) -> None:
        object.__setattr__(self, "errors", tuple(self.errors))
        object.__setattr__(self, "accommodations", tuple(self.accommodations))

    @property
    def error_count(self) -> int:
        return len(self.errors)

    def residual_for(self, signature: ErrorSignature) -> Optional[float]:
        for candidate, residual in self.errors:
            if candidate.family_key == signature.family_key:
                return residual
        return None


@dataclass(frozen=True)
class ErrorTrajectory:
    """History of one error family across completed model generations."""

    signature: ErrorSignature
    occurrences: tuple[tuple[str, float], ...]
    accommodation_history: tuple[AccommodationRecord, ...]
    adequacy_history: tuple[float, ...]
    improvement_history: tuple[float, ...]

    @property
    def occurrence_count(self) -> int:
        return len(self.occurrences)

    @property
    def persistent(self) -> bool:
        return self.occurrence_count >= 2

    @property
    def local_improvement_count(self) -> int:
        return sum(1 for value in self.improvement_history if value > 0)

    @property
    def diminishing_returns(self) -> bool:
        improvements = [x for x in self.improvement_history if x >= 0]
        if len(improvements) < 2:
            return False
        # Require a non-increasing recent trajectory and at least one strictly
        # smaller positive improvement.  This avoids treating a single zero
        # or a noisy reversal as a plateau.
        return (
            improvements[-1] < improvements[0]
            and all(a >= b for a, b in zip(improvements, improvements[1:]))
        )

    @property
    def successful_accommodation_count(self) -> int:
        return sum(1 for a in self.accommodation_history if a.improved)

    @property
    def failed_or_inconclusive_accommodation_count(self) -> int:
        return sum(1 for a in self.accommodation_history if not a.improved)

    @property
    def residual_trend(self) -> Optional[float]:
        if len(self.occurrences) < 2:
            return None
        return self.occurrences[-1][1] - self.occurrences[0][1]

    @property
    def limiting_residual(self) -> bool:
        """Whether the error remains present while adequacy still improves.

        This is deliberately modest: dominance among *all* errors is not
        inferred here because that requires the complete model error surface.
        The caller can supply ``dominant=True`` to ``assess`` when such a
        comparison has been performed.
        """
        return self.persistent and self.local_improvement_count > 0


@dataclass(frozen=True)
class AdequacyProfile:
    """Empirical summary of where a model has demonstrated corrigibility."""

    reliable_conditions: tuple[str, ...] = ()
    corrigible_error_kinds: tuple[ErrorKind, ...] = ()
    recurrent_error_kinds: tuple[ErrorKind, ...] = ()
    stalled_error_kinds: tuple[ErrorKind, ...] = ()
    accommodation_success_rate: float = 0.0
    mean_improvement: float = 0.0
    latest_adequacy: Optional[float] = None


@dataclass(frozen=True)
class DiagnosticAssessment:
    status: DiagnosticStatus
    persistent: bool
    diminishing_returns: bool
    limiting_residual: bool
    structural_non_accommodation: bool
    accommodation_attempts: int
    successful_accommodations: int
    reasons: tuple[str, ...] = ()

    @property
    def eligible_for_oor_review(self) -> bool:
        """Whether the trajectory has reached the pre-OOR diagnostic state.

        This is intentionally *not* an OOR decision.  The future OOR gate will
        consume this state together with independent constraints and any other
        safeguards required by the CVR architecture.
        """
        return self.status is DiagnosticStatus.PERSISTENT_BLIND_SPOT


def error_signature_from_episode(
    episode: EarningsEpisode,
    *,
    kind: ErrorKind = ErrorKind.UNKNOWN,
    location: str = "",
    context_features: Sequence[str] = (),
    relational_features: Sequence[str] = (),
    structural_features: Sequence[str] = (),
) -> tuple[ErrorSignature, float] | None:
    """Convert a completed real CVR episode into a diagnostic error record.

    The adapter uses only the episode's prediction and realized outcome.  It
    does not read post-event evidence from ``episode.evidence`` and therefore
    does not weaken the existing W0 provenance boundary.  Error classification
    and structural descriptors remain explicit inputs rather than being
    inferred from the realized outcome.

    Returns ``None`` when the episode lacks either a prediction or an outcome.
    """
    if episode.prediction is None or episode.outcome is None:
        return None
    prediction = episode.prediction
    outcome = episode.outcome
    residual = float(outcome.realized - prediction.predicted)
    direction = 0 if residual == 0 else (1 if residual > 0 else -1)
    signature = ErrorSignature(
        kind=kind,
        target=prediction.target,
        location=location,
        direction=direction,
        context_features=tuple(context_features),
        relational_features=tuple(relational_features),
        structural_features=tuple(structural_features),
    )
    return signature, residual


def model_generation_from_episodes(
    model_id: str,
    parent_model_id: Optional[str],
    adequacy_score: float,
    episodes: Sequence[EarningsEpisode],
    *,
    classifications: Mapping[str, ErrorKind] | None = None,
    locations: Mapping[str, str] | None = None,
    context_features: Mapping[str, Sequence[str]] | None = None,
    relational_features: Mapping[str, Sequence[str]] | None = None,
    structural_features: Mapping[str, Sequence[str]] | None = None,
    accommodations: Sequence[AccommodationRecord] = (),
) -> ModelGeneration:
    """Build a diagnostic model generation directly from completed episodes.

    ``adequacy_score`` is intentionally supplied by the caller.  CVR 3.2 does
    not equate one episode's prediction accuracy with the model's domain of
    adequacy; the score should therefore come from the existing evaluation
    layer or a validated aggregate measure.
    """
    classifications = classifications or {}
    locations = locations or {}
    context_features = context_features or {}
    relational_features = relational_features or {}
    structural_features = structural_features or {}

    errors: list[tuple[ErrorSignature, float]] = []
    for episode in episodes:
        record = error_signature_from_episode(
            episode,
            kind=classifications.get(episode.episode_id, ErrorKind.UNKNOWN),
            location=locations.get(episode.episode_id, ""),
            context_features=context_features.get(episode.episode_id, ()),
            relational_features=relational_features.get(episode.episode_id, ()),
            structural_features=structural_features.get(episode.episode_id, ()),
        )
        if record is not None:
            errors.append(record)

    return ModelGeneration(
        model_id=model_id,
        parent_model_id=parent_model_id,
        adequacy_score=float(adequacy_score),
        errors=tuple(errors),
        accommodations=tuple(accommodations),
    )


def build_trajectory(
    signature: ErrorSignature,
    generations: Sequence[ModelGeneration],
) -> ErrorTrajectory:
    """Extract one error family's history from completed generations."""
    occurrences: list[tuple[str, float]] = []
    accommodations: list[AccommodationRecord] = []
    adequacy: list[float] = []
    improvements: list[float] = []

    previous_adequacy: Optional[float] = None
    for generation in generations:
        residual = generation.residual_for(signature)
        if residual is None:
            continue
        occurrences.append((generation.model_id, residual))
        adequacy.append(generation.adequacy_score)
        if previous_adequacy is not None:
            improvements.append(generation.adequacy_score - previous_adequacy)
        previous_adequacy = generation.adequacy_score
        # Accommodation attempts are part of the model-generation history,
        # even when a revision removes the residual from that generation.
        # Otherwise a successful accommodation could disappear from the
        # diagnostic record precisely because it worked.
        accommodations.extend(
            a for a in generation.accommodations if a.signature.is_similar_to(signature)
        )

    return ErrorTrajectory(
        signature=signature,
        occurrences=tuple(occurrences),
        accommodation_history=tuple(accommodations),
        adequacy_history=tuple(adequacy),
        improvement_history=tuple(improvements),
    )


def assess_trajectory(
    trajectory: ErrorTrajectory,
    *,
    dominant: bool = False,
    min_occurrences: int = 2,
) -> DiagnosticAssessment:
    """Classify an error trajectory without declaring OOR."""
    persistent = trajectory.occurrence_count >= min_occurrences
    diminishing = trajectory.diminishing_returns
    local_improvement = trajectory.local_improvement_count > 0
    has_attempts = bool(trajectory.accommodation_history)
    successful = trajectory.successful_accommodation_count
    failed = trajectory.failed_or_inconclusive_accommodation_count

    if trajectory.occurrence_count == 0:
        return DiagnosticAssessment(
            DiagnosticStatus.ORDINARY_ERROR,
            False,
            False,
            False,
            False,
            0,
            0,
            ("No completed model generation contains this error family.",),
        )

    if not persistent:
        return DiagnosticAssessment(
            DiagnosticStatus.ORDINARY_ERROR,
            False,
            False,
            False,
            False,
            len(trajectory.accommodation_history),
            successful,
            ("The error has not yet survived successive model generations.",),
        )

    if successful > 0:
        return DiagnosticAssessment(
            DiagnosticStatus.CORRIGIBLE_ERROR,
            True,
            diminishing,
            local_improvement,
            False,
            len(trajectory.accommodation_history),
            successful,
            ("At least one accommodation produced prospective improvement.",),
        )

    if not (diminishing and local_improvement):
        return DiagnosticAssessment(
            DiagnosticStatus.RECURRENT_ERROR,
            True,
            diminishing,
            local_improvement,
            False,
            len(trajectory.accommodation_history),
            successful,
            ("The error recurs, but the evidence is not yet a limiting plateau.",),
        )

    structural = trajectory.signature.kind in {
        ErrorKind.STRUCTURAL,
        getattr(ErrorKind, "CAUSAL_STRUCTURAL", ErrorKind.STRUCTURAL),
    }
    non_accommodated = (not has_attempts or failed > 0) and structural
    limiting = dominant and local_improvement

    if non_accommodated and limiting:
        return DiagnosticAssessment(
            DiagnosticStatus.PERSISTENT_BLIND_SPOT,
            True,
            True,
            True,
            True,
            len(trajectory.accommodation_history),
            successful,
            (
                "The error persists across generations.",
                "Overall adequacy continues to improve while improvement diminishes.",
                "The recurrent residual is identified as limiting remaining improvement.",
                "No successful accommodation within the recorded history resolves the structural error family.",
            ),
        )

    return DiagnosticAssessment(
        DiagnosticStatus.RECURRENT_ERROR,
        True,
        True,
        local_improvement,
        structural and not has_attempts,
        len(trajectory.accommodation_history),
        successful,
        (
            "The error is persistent and improvement is diminishing, but the evidence does not yet establish a limiting blind spot.",
        ),
    )


@dataclass
class ModelHistory:
    """Ordered history of completed CVR model generations.

    This is the bridge between the episode-level adapter and the trajectory
    diagnostics.  It deliberately records completed generations only; it does
    not mutate a live model and it does not infer OOR or generate Z_D.
    """

    generations: list[ModelGeneration] = field(default_factory=list)

    def append(self, generation: ModelGeneration) -> None:
        """Append a completed generation while enforcing lineage continuity."""
        if any(g.model_id == generation.model_id for g in self.generations):
            raise ValueError(f"duplicate model generation: {generation.model_id}")
        if not self.generations:
            if generation.parent_model_id is not None:
                raise ValueError("first model generation must not have a parent")
        else:
            previous = self.generations[-1]
            if generation.parent_model_id != previous.model_id:
                raise ValueError(
                    "generation parent must match the immediately preceding "
                    f"generation ({previous.model_id})"
                )
        self.generations.append(generation)

    def record_generation(
        self,
        model_id: str,
        adequacy_score: float,
        episodes: Sequence[EarningsEpisode],
        *,
        classifications: Mapping[str, ErrorKind] | None = None,
        locations: Mapping[str, str] | None = None,
        context_features: Mapping[str, Sequence[str]] | None = None,
        relational_features: Mapping[str, Sequence[str]] | None = None,
        structural_features: Mapping[str, Sequence[str]] | None = None,
        accommodations: Sequence[AccommodationRecord] = (),
        metadata: Optional[Mapping[str, object]] = None,
    ) -> ModelGeneration:
        """Record a completed revision directly from real CVR episodes.

        This is the integration point between the existing episode/evaluation
        layer and CVR 3.2 diagnostic history.  The caller supplies the
        model-level adequacy score produced by its evaluation procedure; this
        method does not infer adequacy from individual episode accuracy.

        The first recorded generation is treated as the baseline. Subsequent
        generations automatically inherit the immediately preceding model as
        their parent, so callers cannot silently create a disconnected
        revision history.
        """
        parent_model_id = self.latest.model_id if self.latest is not None else None
        generation = model_generation_from_episodes(
            model_id=model_id,
            parent_model_id=parent_model_id,
            adequacy_score=adequacy_score,
            episodes=episodes,
            classifications=classifications,
            locations=locations,
            context_features=context_features,
            relational_features=relational_features,
            structural_features=structural_features,
            accommodations=accommodations,
        )
        if metadata:
            generation = ModelGeneration(
                model_id=generation.model_id,
                parent_model_id=generation.parent_model_id,
                adequacy_score=generation.adequacy_score,
                errors=generation.errors,
                accommodations=generation.accommodations,
                metadata=dict(metadata),
            )
        self.append(generation)
        return generation

    @property
    def latest(self) -> Optional[ModelGeneration]:
        return self.generations[-1] if self.generations else None

    @property
    def adequacy_history(self) -> tuple[float, ...]:
        return tuple(g.adequacy_score for g in self.generations)

    @property
    def improvement_history(self) -> tuple[float, ...]:
        return tuple(
            b.adequacy_score - a.adequacy_score
            for a, b in zip(self.generations, self.generations[1:])
        )

    def error_signatures(self) -> tuple[ErrorSignature, ...]:
        """Return unique observed error families in first-seen order."""
        seen: set[tuple] = set()
        result: list[ErrorSignature] = []
        for generation in self.generations:
            for signature, _ in generation.errors:
                key = signature.family_key
                if key not in seen:
                    seen.add(key)
                    result.append(signature)
        return tuple(result)

    def trajectory(self, signature: ErrorSignature) -> ErrorTrajectory:
        return build_trajectory(signature, self.generations)

    def trajectories(self) -> tuple[ErrorTrajectory, ...]:
        return tuple(self.trajectory(s) for s in self.error_signatures())

    def adequacy_profile(self) -> AdequacyProfile:
        return build_adequacy_profile(self.generations)

    def assess(
        self,
        *,
        dominant_families: Iterable[ErrorSignature] = (),
    ) -> dict[ErrorSignature, DiagnosticAssessment]:
        """Assess every observed error family without invoking OOR."""
        dominant = {s.family_key for s in dominant_families}
        return {
            signature: assess_trajectory(
                self.trajectory(signature),
                dominant=signature.family_key in dominant,
            )
            for signature in self.error_signatures()
        }


def build_adequacy_profile(
    generations: Sequence[ModelGeneration],
) -> AdequacyProfile:
    """Build a lightweight empirical adequacy profile from model history."""
    if not generations:
        return AdequacyProfile()

    all_accommodations = [a for g in generations for a in g.accommodations]
    successful = sum(1 for a in all_accommodations if a.improved)
    rates = successful / len(all_accommodations) if all_accommodations else 0.0

    improvements = [
        b.adequacy_score - a.adequacy_score
        for a, b in zip(generations, generations[1:])
    ]
    mean_improvement = sum(improvements) / len(improvements) if improvements else 0.0

    kinds = [signature.kind for g in generations for signature, _ in g.errors]
    corrigible = tuple(sorted({a.signature.kind for a in all_accommodations if a.improved}, key=lambda x: x.value))
    recurrent = tuple(sorted({kind for kind in kinds if kinds.count(kind) >= 2}, key=lambda x: x.value))

    return AdequacyProfile(
        corrigible_error_kinds=corrigible,
        recurrent_error_kinds=recurrent,
        accommodation_success_rate=rates,
        mean_improvement=mean_improvement,
        latest_adequacy=generations[-1].adequacy_score,
    )
