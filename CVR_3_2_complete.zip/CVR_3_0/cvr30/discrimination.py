from __future__ import annotations

from dataclasses import dataclass
from math import sqrt
from typing import Mapping, Optional, Sequence


def wilson_interval(successes: int, n: int, z: float = 1.96) -> tuple[float, float]:
    """Wilson score interval for a binomial proportion.

    Preferred over the naive normal-approximation interval at small n, where
    the normal interval can extend outside [0, 1] or collapse to a
    zero-width point at p=0 or p=1 -- exactly the small-n regime this
    project's candidates (n=4, n=7) actually live in. A wide interval here
    is the honest signal that a point estimate is not to be trusted yet.
    """
    if n <= 0:
        return (0.0, 1.0)
    phat = successes / n
    denom = 1 + z * z / n
    center = phat + z * z / (2 * n)
    margin = z * sqrt((phat * (1 - phat) + z * z / (4 * n)) / n)
    lower = (center - margin) / denom
    upper = (center + margin) / denom
    return (max(0.0, lower), min(1.0, upper))


@dataclass(frozen=True)
class DiscriminationResult:
    """Result of the population-level discrimination test.

    This is deliberately NOT the same object as an AblationResult. Ablation
    asks whether one model's fit depends on the candidate; discrimination
    asks whether the candidate condition is actually specific to the
    hypothesized cause across a population, including cases where the cause
    is absent. A candidate can pass ablation and classical necessity while
    still failing discrimination (the fever/measles pattern) -- these are
    tracked as separate, non-collapsible axes rather than merged into one
    score, per the project's explicit guardrail on this point.
    """

    candidate_id: str
    reference_class: str
    n_cause: int
    n_control: int
    sensitivity: float
    sensitivity_interval: tuple[float, float]
    specificity: float
    specificity_interval: tuple[float, float]
    likelihood_ratio_positive: Optional[float]
    youden_j: float
    interpretation: str

    @property
    def well_powered(self) -> bool:
        """A minimal, deliberately conservative floor -- not a claim that
        n>=5 on each side is *adequate*, only that below it the interval
        widths make any interpretation close to meaningless."""
        return self.n_cause >= 5 and self.n_control >= 5


def discriminate(
    candidate_id: str,
    reference_class: str,
    cause_population: Sequence[bool],
    control_population: Sequence[bool],
) -> DiscriminationResult:
    """Population-level discrimination test (Law of Likelihood: Hacking,
    Royall). NOT an ablation/removal test on a single fitted model -- see
    `ablation.py` for that, kept intentionally separate.

    cause_population: one bool per case where the hypothesized cause is
        present, indicating whether the candidate condition also occurred.
    control_population: one bool per case in the negative-control set --
        cases where the hypothesized cause is independently judged absent --
        indicating whether the candidate condition occurred anyway. If this
        occurs widely, the candidate fails to discriminate the cause
        regardless of how reliably it occurs given the cause.

    reference_class must be named explicitly by the caller. There is no
    implicit default population -- picking one is a substantive modeling
    decision, not a detail this function is allowed to paper over.
    """
    n_cause = len(cause_population)
    n_control = len(control_population)

    sens_hits = sum(1 for c in cause_population if c)
    sensitivity = sens_hits / n_cause if n_cause else 0.0
    sensitivity_interval = wilson_interval(sens_hits, n_cause)

    control_hits = sum(1 for c in control_population if c)
    false_positive_rate = control_hits / n_control if n_control else 1.0
    specificity = 1.0 - false_positive_rate
    fp_lo, fp_hi = wilson_interval(control_hits, n_control)
    specificity_interval = (1.0 - fp_hi, 1.0 - fp_lo)

    if specificity >= 1.0:
        # 0 hits in the control population: LR+ is formally unbounded, not
        # infinitely good evidence -- report as undefined rather than
        # dividing by zero or inventing a large number.
        lr_plus: Optional[float] = None
    else:
        lr_plus = sensitivity / (1.0 - specificity)

    youden_j = sensitivity + specificity - 1.0

    if n_cause == 0 or n_control == 0:
        interpretation = (
            "Insufficient population on one side of the reference class -- "
            "the discrimination test cannot run."
        )
    elif lr_plus is None:
        interpretation = (
            "Candidate did not occur anywhere in this negative-control sample, "
            "so LR+ is undefined (unbounded) rather than infinite -- treat as "
            "provisional pending a larger control set, not as confirmed "
            "perfect discrimination."
        )
    elif lr_plus >= 10:
        interpretation = "Strong discriminator: rarely occurs without the hypothesized cause."
    elif lr_plus >= 2:
        interpretation = "Moderate discriminator."
    else:
        interpretation = (
            "Weak discriminator: occurs about as often without the cause as "
            "with it (the fever/measles pattern) -- passes classical "
            "necessity but fails discrimination."
        )

    return DiscriminationResult(
        candidate_id=candidate_id,
        reference_class=reference_class,
        n_cause=n_cause,
        n_control=n_control,
        sensitivity=sensitivity,
        sensitivity_interval=sensitivity_interval,
        specificity=specificity,
        specificity_interval=specificity_interval,
        likelihood_ratio_positive=lr_plus,
        youden_j=youden_j,
        interpretation=interpretation,
    )


def build_reference_population(
    rows: Sequence[Mapping[str, object]],
    *,
    cause_field: str,
    condition_field: str,
) -> tuple[list[bool], list[bool]]:
    """Split a flat panel into (cause_population, control_population) for
    `discriminate`, given named boolean fields for the hypothesized cause
    and the candidate condition.

    This is the explicit reference-class split: the caller states which
    population and which fields are meant. There is no implicit default --
    e.g. for the AAPL panel, `cause_field` might mark "strict contradiction"
    and `condition_field` might mark "negative 30-day EPS revision"; the 15
    non-contradiction AAPL events become the control_population for free
    once cause_field is set correctly, rather than needing to be
    hand-assembled.
    """
    cause_population = [bool(r[condition_field]) for r in rows if r.get(cause_field)]
    control_population = [bool(r[condition_field]) for r in rows if not r.get(cause_field)]
    return cause_population, control_population
