from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Mapping, Optional

from .provenance import freeze_evidence
from .types import Evidence, Outcome, Prediction


@dataclass
class EarningsEpisode:
    episode_id: str
    asset: str
    event_time: datetime
    w0_boundary: datetime
    evidence: list[Evidence]
    outcome: Optional[Outcome] = None
    prediction: Optional[Prediction] = None
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def frozen_w0(self) -> dict[str, Evidence]:
        return freeze_evidence(self.evidence, self.w0_boundary)

    def feature_dict(self) -> dict[str, Any]:
        return {k: e.value for k, e in self.frozen_w0().items()}

    def has_outcome(self) -> bool:
        return self.outcome is not None
