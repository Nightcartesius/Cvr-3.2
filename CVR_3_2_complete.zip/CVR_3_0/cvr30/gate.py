from __future__ import annotations

from dataclasses import dataclass
from math import log10
from typing import Optional

from .ablation import AblationResult
from .discrimination import DiscriminationResult
from .necessity import NecessityResult
from .stability import StabilityResult
from .types import CausalStatus, CandidateResult


@dataclass(frozen=True)
class GateThresholds:
    min_instances: int = 3
    moderate_necessity: float = 0.50
    strong_necessity: float = 0.80
    minimum_stability: float = 0.67
    # LR+ bands, following the informal clinical diagnostic-test convention
    # (Jaeschke et al. 1994): treated here as an explicit, overridable
    # default rather than a derived constant. Weak discrimination can veto
    # an otherwise-supported candidate; strong discrimination can raise the
    # ceiling but never substitutes for necessity, stability, or a minimum
    # instance count.
    weak_lr: float = 2.0
    strong_lr: float = 10.0


def _legacy_status(
    candidate_id: str,
    ablation: AblationResult,
    necessity: NecessityResult,
    stability: StabilityResult,
    thresholds: GateThresholds,
) -> tuple[CausalStatus, float, list[str], dict]:
    """The pre-discrimination decision path, preserved for callers who have
    not yet supplied a DiscriminationResult (no negative-control population
    available yet). This path is retained for backward compatibility, but
    it is still the nested-threshold shape the project's conceptual work
    flagged for replacement -- supply `discrimination` whenever a
    negative-control population exists; see discrimination.py.
    """
    reasons: list[str] = []
    evidence = {
        "ablation_delta_error": ablation.delta_error,
        "necessity_rate": necessity.necessity_rate,
        "stable_sign": stability.stable_sign,
        "transfer_count": stability.transfer_count,
    }

    if stability.transfer_count < thresholds.min_instances:
        return (
            CausalStatus.INSUFFICIENT_DATA,
            0.25,
            ["Cross-instance evidence is below the minimum test count."],
            evidence,
        )

    if (
        ablation.improves_fit
        and necessity.necessity_rate >= thresholds.strong_necessity
        and stability.stable_sign
        and stability.transfer_count >= thresholds.min_instances
    ):
        reasons += [
            "Candidate improves model fit under ablation testing.",
            "Candidate shows strong model-relative counterfactual resistance.",
            "Effect sign is stable across tested instances.",
            "No population-level discrimination test was run -- this status "
            "reflects necessity/ablation/stability only, not whether the "
            "candidate is actually specific to this cause versus rivals.",
        ]
        return CausalStatus.SUPPORTED_CANDIDATE, 0.85, reasons, evidence

    if (
        ablation.improves_fit
        and necessity.necessity_rate >= thresholds.moderate_necessity
        and stability.stable_sign
    ):
        reasons += [
            "Candidate improves model fit.",
            "Candidate has moderate counterfactual resistance.",
            "Candidate transfers with a stable sign in the available sample.",
        ]
        return CausalStatus.MODERATE_PROVISIONAL, 0.65, reasons, evidence

    if not ablation.improves_fit and necessity.necessity_rate < thresholds.moderate_necessity:
        reasons.append("Candidate does not show sufficient dependence in the current tests.")
        return CausalStatus.REJECTED_CANDIDATE, 0.20, reasons, evidence

    reasons.append("Evidence is mixed; no causal promotion is warranted.")
    return CausalStatus.INCONCLUSIVE, 0.50, reasons, evidence


def _discrimination_score(disc: DiscriminationResult) -> float:
    """Continuous score from LR+, rather than a branch-assigned constant.

    Log-anchored at LR+=1 (no discriminating power -> 0.5) so the score
    grows with evidential strength but never asymptotes to false certainty.
    An undefined LR+ (zero hits in the control population) is capped
    low-moderate rather than treated as perfect, since with small samples it
    usually reflects an under-powered control set, not genuine perfect
    specificity.
    """
    if disc.likelihood_ratio_positive is None:
        return 0.55 if disc.well_powered else 0.45
    lr = disc.likelihood_ratio_positive
    if lr <= 0:
        return 0.05
    raw = 0.5 + 0.35 * log10(lr)
    return max(0.05, min(0.95, raw))


def causal_status_gate(
    candidate_id: str,
    *,
    ablation: Optional[AblationResult],
    necessity: Optional[NecessityResult],
    stability: Optional[StabilityResult],
    discrimination: Optional[DiscriminationResult] = None,
    thresholds: GateThresholds = GateThresholds(),
) -> CandidateResult:
    if ablation is None or necessity is None or stability is None:
        return CandidateResult(
            candidate_id,
            CausalStatus.INSUFFICIENT_DATA,
            0.0,
            {},
            ["One or more required tests are missing."],
        )

    status, score, reasons, evidence = _legacy_status(
        candidate_id, ablation, necessity, stability, thresholds
    )

    if discrimination is None:
        return CandidateResult(candidate_id, status, score, evidence, reasons)

    # Discrimination is a separate, non-collapsible axis that can veto or
    # raise the ceiling on the legacy result -- it never overwrites it
    # outright, and its own numbers are never merged into ablation's or
    # necessity's evidence fields.
    evidence = dict(evidence)
    evidence["reference_class"] = discrimination.reference_class
    evidence["n_cause"] = discrimination.n_cause
    evidence["n_control"] = discrimination.n_control
    evidence["sensitivity"] = discrimination.sensitivity
    evidence["sensitivity_interval"] = discrimination.sensitivity_interval
    evidence["specificity"] = discrimination.specificity
    evidence["specificity_interval"] = discrimination.specificity_interval
    evidence["likelihood_ratio_positive"] = discrimination.likelihood_ratio_positive
    evidence["youden_j"] = discrimination.youden_j

    lr = discrimination.likelihood_ratio_positive
    disc_score = _discrimination_score(discrimination)
    reasons = list(reasons) + [
        f"Discrimination test ({discrimination.reference_class}): "
        f"{discrimination.interpretation}"
    ]

    if not discrimination.well_powered:
        reasons.append(
            "Reference-class population is small on at least one side "
            f"(n_cause={discrimination.n_cause}, n_control={discrimination.n_control}); "
            "treat the discrimination result as an early signal, not a settled one."
        )

    weak_discriminator = lr is not None and lr < thresholds.weak_lr
    strong_discriminator = lr is not None and lr >= thresholds.strong_lr

    if weak_discriminator and status in (
        CausalStatus.SUPPORTED_CANDIDATE,
        CausalStatus.MODERATE_PROVISIONAL,
    ):
        # Veto: necessity/ablation/stability alone cannot promote a
        # candidate that fails discrimination -- the fever/measles case.
        reasons.append(
            f"Downgraded from a legacy status of '{status.value}': the "
            "candidate is not specific to this cause relative to the stated "
            "reference class, regardless of how it performed on necessity, "
            "ablation, and stability alone."
        )
        status = CausalStatus.INCONCLUSIVE
        score = min(score, disc_score)
    elif strong_discriminator and status == CausalStatus.MODERATE_PROVISIONAL:
        # Discrimination can raise the ceiling, but only alongside the
        # existing floors (min instance count, necessity, stability) that
        # _legacy_status already required to reach MODERATE_PROVISIONAL in
        # the first place -- it does not bypass them.
        reasons.append(
            "Promoted from 'moderate_provisional': candidate also shows "
            "strong population-level discrimination against the stated "
            "reference class."
        )
        status = CausalStatus.SUPPORTED_CANDIDATE
        score = max(score, disc_score)
    else:
        # Neither a strong veto nor a strong promotion: blend the two axes
        # into the score without changing the category, so the number
        # reflects both without letting either alone decide it.
        score = round((score + disc_score) / 2, 3)

    if not discrimination.well_powered:
        # Small populations compress how far the score can move in either
        # direction -- an honest reflection of wide Wilson intervals rather
        # than a hidden precision claim.
        score = 0.5 + (score - 0.5) * 0.6

    return CandidateResult(candidate_id, status, round(score, 3), evidence, reasons)
