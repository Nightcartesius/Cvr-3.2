"""Autonomous revision loop driver for CVR 3.2.

This module wires together the revision orchestrator, the diagnostic
layer, the OOR gate, and Z_D candidate generation into a single
autonomous pipeline:

    M_t -> orchestrator.run_cycle() -> M_{t+1}
        -> ModelHistory.assess()
        -> review_history_for_oor()
        -> generate_zd_candidate()
        -> stop or continue

The loop driver is the explicit coordinator that connects the
previously decoupled components.  It does not modify any of them.
The orchestrator still does not import ``oor`` or ``zd_generation``;
the loop driver is the module that bridges them.

The loop does not feed a generated ``ZDCandidateSpec`` back into the
model.  Testing and incorporating Z_D belongs to a later step that
uses real candidate evidence and ``run_candidate_pilot()``.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Iterable, Mapping, Optional, Sequence

from .diagnostic import (
    DiagnosticAssessment,
    ErrorSignature,
    ErrorTrajectory,
    ModelHistory,
)
from .episode import EarningsEpisode
from .oor import OORGateResult, OORGateStatus, review_history_for_oor
from .orchestrator import RevisionCycleResult, RevisionOrchestrator
from .zd_generation import ZDGenerationResult, generate_zd_candidate


# -- Injected policies ------------------------------------------------------

EpisodeProvider = Callable[
    [int, Any, ModelHistory],
    Sequence[EarningsEpisode],
]
"""Produce the episodes to evaluate in one cycle.

Receives the cycle index, the current model, and the model history.
Returns a sequence of completed ``EarningsEpisode`` records.  This
supports both fixed re-evaluation (same episodes each cycle) and
walk-forward batches (different episodes per cycle).
"""

DominancePolicy = Callable[
    [ModelHistory],
    Iterable[ErrorSignature],
]
"""Return the dominant error families for diagnostic assessment.

This is essential because ``ModelHistory.assess(dominant_families=...)``
only produces ``PERSISTENT_BLIND_SPOT`` when dominance is supplied.
The default policy returns no dominant families — it does not silently
mark all errors dominant.
"""


@dataclass(frozen=True)
class IndependentConstraint:
    """An independent constraint that can corroborate a persistent error."""

    present: bool
    constraint_id: str = ""
    notes: str = ""


IndependentConstraintProvider = Callable[
    [Sequence[ErrorTrajectory], Mapping[ErrorSignature, DiagnosticAssessment], ModelHistory],
    Mapping[ErrorSignature, IndependentConstraint],
]
"""Supply independent constraints for the OOR gate.

Receives the trajectories, assessments, and model history.  Returns a
mapping from error signature to independent constraint.  This is a
substantive caller decision — the loop does not infer constraints.
"""


# -- Loop status ------------------------------------------------------------

class RevisionLoopStatus(str, Enum):
    """Why the loop stopped."""

    ZD_CANDIDATE_GENERATED = "zd_candidate_generated"
    OOR_CONSTRAINT_REQUIRED = "oor_constraint_required"
    ADEQUACY_PLATEAU = "adequacy_plateau"
    MAX_CYCLES_REACHED = "max_cycles_reached"
    NO_EPISODES = "no_episodes"


# -- Loop result ------------------------------------------------------------

@dataclass(frozen=True)
class RevisionLoopResult:
    """Output of an autonomous revision loop run."""

    status: RevisionLoopStatus
    final_model: Any
    cycles: tuple[RevisionCycleResult, ...]
    assessments: Mapping[ErrorSignature, DiagnosticAssessment]
    trajectories: tuple[ErrorTrajectory, ...]
    oor_results: tuple[OORGateResult, ...]
    zd_results: tuple[ZDGenerationResult, ...]
    history: ModelHistory
    reasons: tuple[str, ...] = ()


# -- Episode provider helpers -----------------------------------------------

def fixed_episode_provider(
    episodes: Sequence[EarningsEpisode],
) -> EpisodeProvider:
    """Return an episode provider that evaluates the same episodes each cycle."""

    def _provider(
        cycle_index: int, model: Any, history: ModelHistory
    ) -> Sequence[EarningsEpisode]:
        return episodes

    return _provider


def batched_episode_provider(
    batches: Sequence[Sequence[EarningsEpisode]],
) -> EpisodeProvider:
    """Return an episode provider that cycles through fixed batches.

    If the loop runs longer than the number of batches, the last batch
    is reused.
    """

    def _provider(
        cycle_index: int, model: Any, history: ModelHistory
    ) -> Sequence[EarningsEpisode]:
        if not batches:
            return ()
        index = min(cycle_index, len(batches) - 1)
        return batches[index]

    return _provider


# -- Default policies -------------------------------------------------------

def no_dominant_families(history: ModelHistory) -> Iterable[ErrorSignature]:
    """Default dominance policy: return no dominant families.

    This is deliberately conservative.  ``PERSISTENT_BLIND_SPOT`` will
    not emerge under this policy; the caller must supply a dominance
    policy that identifies which error families are limiting.
    """
    return ()


def no_independent_constraints(
    trajectories: Sequence[ErrorTrajectory],
    assessments: Mapping[ErrorSignature, DiagnosticAssessment],
    history: ModelHistory,
) -> Mapping[ErrorSignature, IndependentConstraint]:
    """Default constraint provider: no constraints for any family."""
    return {}


# -- Loop driver ------------------------------------------------------------

@dataclass
class RevisionLoop:
    """Autonomous revision loop that coordinates the full CVR 3.2 chain.

    The loop runs orchestrator cycles, checks the diagnostic state
    after each cycle, and when a persistent blind spot emerges, runs
    the OOR gate and generates a Z_D candidate.  The loop stops when:

    - A Z_D candidate is generated (persistent blind spot + constraint).
    - The OOR gate requires an independent constraint that is not supplied.
    - Adequacy improvement plateaus without a blind spot.
    - The maximum number of cycles is reached.
    - No episodes are provided for a cycle.
    """

    orchestrator: RevisionOrchestrator
    episode_provider: EpisodeProvider
    dominance_policy: DominancePolicy = field(default=no_dominant_families)
    constraint_provider: IndependentConstraintProvider = field(
        default=no_independent_constraints
    )
    max_cycles: int = 10
    min_cycles_before_diagnostics: int = 2
    check_every: int = 1
    plateau_window: int = 2
    min_adequacy_improvement: float = 0.0

    def __post_init__(self) -> None:
        if self.max_cycles < 1:
            raise ValueError("max_cycles must be at least 1")
        if self.min_cycles_before_diagnostics < 1:
            raise ValueError("min_cycles_before_diagnostics must be at least 1")
        if self.check_every < 1:
            raise ValueError("check_every must be at least 1")
        if self.plateau_window < 1:
            raise ValueError("plateau_window must be at least 1")

    def run(self, initial_model: Any) -> RevisionLoopResult:
        """Run the autonomous revision loop from an initial model.

        Returns a ``RevisionLoopResult`` describing why the loop stopped
        and what it produced.
        """
        current_model = initial_model
        cycles: list[RevisionCycleResult] = []
        assessments: dict[ErrorSignature, DiagnosticAssessment] = {}
        trajectories: tuple[ErrorTrajectory, ...] = ()
        oor_results: list[OORGateResult] = []
        zd_results: list[ZDGenerationResult] = []
        reasons: list[str] = []

        for cycle_index in range(self.max_cycles):
            episodes = self.episode_provider(
                cycle_index, current_model, self.orchestrator.history
            )

            if not episodes:
                reasons.append(
                    f"Episode provider returned no episodes at cycle {cycle_index}."
                )
                return RevisionLoopResult(
                    status=RevisionLoopStatus.NO_EPISODES,
                    final_model=current_model,
                    cycles=tuple(cycles),
                    assessments=assessments,
                    trajectories=trajectories,
                    oor_results=tuple(oor_results),
                    zd_results=tuple(zd_results),
                    reasons=tuple(reasons),
                    history=self.orchestrator.history,
                )

            cycle = self.orchestrator.run_cycle(current_model, episodes)
            cycles.append(cycle)
            current_model = cycle.next_model

            # Check diagnostics only after enough cycles have accumulated.
            if cycle_index + 1 < self.min_cycles_before_diagnostics:
                continue
            if (cycle_index + 1 - self.min_cycles_before_diagnostics) % self.check_every != 0:
                continue

            dominant = list(self.dominance_policy(self.orchestrator.history))
            assessments = self.orchestrator.history.assess(
                dominant_families=dominant
            )
            trajectories = self.orchestrator.history.trajectories()

            # Run the OOR gate on all trajectories.
            constraint_map = self.constraint_provider(
                trajectories, assessments, self.orchestrator.history
            )
            independent_constraints: dict[ErrorSignature, bool] = {}
            constraint_ids: dict[ErrorSignature, str] = {}
            for sig, constraint in constraint_map.items():
                independent_constraints[sig] = constraint.present
                constraint_ids[sig] = constraint.constraint_id

            oor_results = review_history_for_oor(
                trajectories,
                assessments,
                independent_constraints=independent_constraints,
                constraint_ids=constraint_ids,
            )

            # Generate Z_D candidates for any eligible OOR results.
            for oor in oor_results:
                if oor.eligible_for_zd_generation:
                    zd = generate_zd_candidate(oor)
                    zd_results.append(zd)

            if zd_results:
                reasons.append(
                    f"Z_D candidate generated at cycle {cycle_index} after "
                    f"a persistent blind spot passed the OOR gate."
                )
                return RevisionLoopResult(
                    status=RevisionLoopStatus.ZD_CANDIDATE_GENERATED,
                    final_model=current_model,
                    cycles=tuple(cycles),
                    assessments=assessments,
                    trajectories=trajectories,
                    oor_results=tuple(oor_results),
                    zd_results=tuple(zd_results),
                    reasons=tuple(reasons),
                    history=self.orchestrator.history,
                )

            # Check if any OOR result requires an independent constraint.
            constraint_required = any(
                r.status is OORGateStatus.INDEPENDENT_CONSTRAINT_REQUIRED
                for r in oor_results
            )
            if constraint_required:
                reasons.append(
                    f"OOR gate requires an independent constraint at cycle "
                    f"{cycle_index}, but none was supplied."
                )
                return RevisionLoopResult(
                    status=RevisionLoopStatus.OOR_CONSTRAINT_REQUIRED,
                    final_model=current_model,
                    cycles=tuple(cycles),
                    assessments=assessments,
                    trajectories=trajectories,
                    oor_results=tuple(oor_results),
                    zd_results=tuple(zd_results),
                    reasons=tuple(reasons),
                    history=self.orchestrator.history,
                )

            # Check for adequacy plateau (without a blind spot).
            if self._plateaued():
                reasons.append(
                    f"Adequacy improvement plateaued over the last "
                    f"{self.plateau_window} cycles without a persistent "
                    f"blind spot."
                )
                return RevisionLoopResult(
                    status=RevisionLoopStatus.ADEQUACY_PLATEAU,
                    final_model=current_model,
                    cycles=tuple(cycles),
                    assessments=assessments,
                    trajectories=trajectories,
                    oor_results=tuple(oor_results),
                    zd_results=tuple(zd_results),
                    reasons=tuple(reasons),
                    history=self.orchestrator.history,
                )

        reasons.append(
            f"Maximum cycles ({self.max_cycles}) reached without generating "
            f"a Z_D candidate."
        )
        return RevisionLoopResult(
            status=RevisionLoopStatus.MAX_CYCLES_REACHED,
            final_model=current_model,
            cycles=tuple(cycles),
            assessments=assessments,
            trajectories=trajectories,
            oor_results=tuple(oor_results),
            zd_results=tuple(zd_results),
            reasons=tuple(reasons),
            history=self.orchestrator.history,
        )

    def _plateaued(self) -> bool:
        """Check whether adequacy improvement has plateaued."""
        improvements = self.orchestrator.history.improvement_history
        if len(improvements) < self.plateau_window:
            return False
        recent = improvements[-self.plateau_window:]
        return all(x <= self.min_adequacy_improvement for x in recent)
