from __future__ import annotations

from dataclasses import dataclass
from math import isfinite
from typing import Optional


@dataclass(frozen=True)
class Measurement:
    name: str
    value: Optional[float]
    source: str
    point_in_time: bool
    notes: str = ""

    @property
    def usable(self) -> bool:
        return self.value is not None and isfinite(float(self.value))


def pct_change(old: Optional[float], new: Optional[float]) -> Optional[float]:
    if old is None or new is None or old == 0:
        return None
    return 100.0 * (new - old) / abs(old)


def abnormal_return(asset_return: Optional[float],
                    benchmark_return: Optional[float]) -> Optional[float]:
    if asset_return is None or benchmark_return is None:
        return None
    return asset_return - benchmark_return


def validate_point_in_time_revision(
    revision_value: Optional[float],
    *,
    point_in_time: bool,
    source: str,
) -> Measurement:
    """A revision is not accepted as a reconstructed revision path merely
    because an event-time consensus number exists."""
    return Measurement(
        name="expectation_revision",
        value=revision_value,
        source=source,
        point_in_time=point_in_time,
        notes=(
            "Accepted as pre-event revision only when point_in_time=True."
            if point_in_time
            else "Event-time value only; not treated as reconstructed revision path."
        ),
    )
