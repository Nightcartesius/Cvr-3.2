from __future__ import annotations

from dataclasses import dataclass
from math import sqrt
from typing import Iterable, Mapping, Sequence


@dataclass(frozen=True)
class LinearModel:
    model_id: str
    features: tuple[str, ...]
    intercept: float = 0.0
    coefficients: tuple[float, ...] = ()

    def predict(self, row: Mapping[str, float]) -> float:
        if len(self.features) != len(self.coefficients):
            raise ValueError("features and coefficients must have equal length")
        value = self.intercept
        for name, coef in zip(self.features, self.coefficients):
            value += coef * float(row.get(name, 0.0))
        return value


def fit_univariate(
    model_id: str,
    x_name: str,
    xs: Sequence[float],
    ys: Sequence[float],
) -> LinearModel:
    if len(xs) != len(ys) or not xs:
        raise ValueError("x and y must have equal non-zero length")
    xbar = sum(xs) / len(xs)
    ybar = sum(ys) / len(ys)
    den = sum((x - xbar) ** 2 for x in xs)
    beta = 0.0 if den == 0 else sum((x - xbar) * (y - ybar) for x, y in zip(xs, ys)) / den
    alpha = ybar - beta * xbar
    return LinearModel(model_id, (x_name,), alpha, (beta,))


def rmse(predicted: Iterable[float], actual: Iterable[float]) -> float:
    pairs = list(zip(predicted, actual))
    if not pairs:
        raise ValueError("cannot calculate RMSE on empty data")
    return sqrt(sum((p - a) ** 2 for p, a in pairs) / len(pairs))
