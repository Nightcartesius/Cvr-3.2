from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Mapping, Sequence


@dataclass(frozen=True)
class NecessityResult:
    candidate_id: str
    necessary_count: int
    tested_count: int
    necessity_rate: float
    resistant: bool
    interpretation: str


def counterfactual_necessity(
    candidate_id: str,
    worlds: Sequence[Mapping[str, float]],
    resolution: Callable[[Mapping[str, float]], bool],
    ablation: Callable[[Mapping[str, float]], Mapping[str, float]],
) -> NecessityResult:
    """Test E -> C / equivalently not-C -> not-E over candidate worlds.

    Necessity is epistemic/model-relative. A failed ablation is evidence
    against necessity, not metaphysical refutation.
    """
    necessary = 0
    tested = 0
    for world in worlds:
        if not resolution(world):
            continue
        tested += 1
        stripped = ablation(world)
        if not resolution(stripped):
            necessary += 1

    rate = necessary / tested if tested else 0.0
    return NecessityResult(
        candidate_id=candidate_id,
        necessary_count=necessary,
        tested_count=tested,
        necessity_rate=rate,
        resistant=bool(tested and rate >= 0.8),
        interpretation=(
            "Candidate shows strong counterfactual resistance in tested worlds."
            if tested and rate >= 0.8
            else "Candidate has not demonstrated strong necessity in the tested worlds."
        ),
    )


def remove_candidate(
    candidate_id: str,
    world: Mapping[str, float],
) -> dict[str, float]:
    result = dict(world)
    result[candidate_id] = 0.0
    return result
