from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Mapping, Optional, Sequence

from .diagnostic import DiagnosticAssessment, ErrorSignature, ErrorTrajectory
from .types import ErrorDiagnosis, ErrorKind


@dataclass(frozen=True)
class OORObservation:
    predicted: float
    actual: float
    persistence: float
    independent_constraint: bool
    notes: str = ""

    @property
    def discrepancy(self) -> float:
        return self.actual - self.predicted


def diagnose(
    prediction: float,
    actual: float,
    *,
    persistence: float,
    independent_constraint: bool,
    classification: ErrorKind = ErrorKind.UNKNOWN,
    scale: Optional[float] = None,
) -> ErrorDiagnosis:
    error = actual - prediction
    normalized = None if scale in (None, 0) else error / scale
    return ErrorDiagnosis(
        error=error,
        normalized_error=normalized,
        kind=classification,
        persistence=persistence,
        notes=(
            "Candidate OOR is stronger when discrepancy persists under an "
            "independent constraint."
            if independent_constraint and persistence > 0
            else "Insufficient basis for strong OOR attribution."
        ),
    )


def is_candidate_oor(obs: OORObservation, min_persistence: float = 0.5) -> bool:
    return (
        abs(obs.discrepancy) > 0
        and obs.persistence >= min_persistence
        and obs.independent_constraint
    )


# -- Trajectory-level OOR gate -----------------------------------------------

class OORGateStatus(str, Enum):
    """Outcome of reviewing an error trajectory through the OOR gate.

    These are downstream of the diagnostic layer.  A persistent blind
    spot is a pre-OOR diagnostic state; the gate converts it into an
    OOR determination when an independent constraint is available.
    """

    NOT_REVIEWABLE = "not_reviewable"
    INDEPENDENT_CONSTRAINT_REQUIRED = "independent_constraint_required"
    NOT_OOR = "not_oor"
    CANDIDATE_OOR = "candidate_oor"


@dataclass(frozen=True)
class OORGateResult:
    """Result of reviewing one error trajectory through the OOR gate.

    This is the downstream consumer of ``DiagnosticAssessment``.  It
    does not generate ``Z_D``; it exposes
    ``eligible_for_zd_generation`` as the handoff point for a future
    Z_D generation step.
    """

    signature: ErrorSignature
    status: OORGateStatus
    candidate_oor: bool
    persistence_score: float
    latest_residual: Optional[float]
    independent_constraint: bool
    constraint_id: str = ""
    reasons: tuple[str, ...] = ()

    @property
    def eligible_for_zd_generation(self) -> bool:
        """Whether the gate has opened the door to Z_D generation.

        This is intentionally not a Z_D object.  The future Z_D
        generation step will consume this eligibility together with
        its own substantive requirements.
        """
        return self.candidate_oor


def review_trajectory_for_oor(
    trajectory: ErrorTrajectory,
    assessment: DiagnosticAssessment,
    *,
    independent_constraint: bool,
    constraint_id: str = "",
    min_persistence: float = 0.5,
    min_occurrences_for_full_persistence: int = 2,
    residual_tolerance: float = 0.0,
) -> OORGateResult:
    """Review one error trajectory through the OOR gate.

    This is the downstream boundary between the diagnostic layer and
    OOR determination.  It consumes a ``DiagnosticAssessment`` (which
    already encodes whether the trajectory has reached a persistent
    blind spot) together with an independent constraint supplied by the
    caller.

    The gate does not generate ``Z_D``.  It produces an
    ``OORGateResult`` whose ``eligible_for_zd_generation`` property is
    the handoff point for future Z_D generation.

    Parameters
    ----------
    trajectory:
        The error family's history across completed generations.
    assessment:
        The diagnostic assessment of that trajectory.
    independent_constraint:
        Whether an independent constraint corroborates the persistent
        error.  This is a substantive caller decision, not something
        the gate infers.
    constraint_id:
        Optional identifier for the independent constraint, for
        provenance.
    min_persistence:
        Minimum persistence score (0-1) for a candidate OOR.
    min_occurrences_for_full_persistence:
        Number of occurrences at which persistence is considered 1.0.
    residual_tolerance:
        Absolute threshold below which a residual is treated as zero.
    """
    signature = trajectory.signature

    if not assessment.eligible_for_oor_review:
        return OORGateResult(
            signature=signature,
            status=OORGateStatus.NOT_REVIEWABLE,
            candidate_oor=False,
            persistence_score=0.0,
            latest_residual=trajectory.occurrences[-1][1]
            if trajectory.occurrences
            else None,
            independent_constraint=independent_constraint,
            constraint_id=constraint_id,
            reasons=(
                "Trajectory has not reached the persistent-blind-spot "
                "diagnostic state required for OOR review.",
            ),
        )

    if not independent_constraint:
        return OORGateResult(
            signature=signature,
            status=OORGateStatus.INDEPENDENT_CONSTRAINT_REQUIRED,
            candidate_oor=False,
            persistence_score=min(
                1.0,
                trajectory.occurrence_count / max(1, min_occurrences_for_full_persistence),
            ),
            latest_residual=trajectory.occurrences[-1][1]
            if trajectory.occurrences
            else None,
            independent_constraint=False,
            constraint_id=constraint_id,
            reasons=(
                "A persistent blind spot has been diagnosed, but no "
                "independent constraint corroborates it.  OOR cannot be "
                "declared on persistence alone.",
            ),
        )

    latest_residual = (
        trajectory.occurrences[-1][1] if trajectory.occurrences else None
    )
    persistence_score = min(
        1.0,
        trajectory.occurrence_count / max(1, min_occurrences_for_full_persistence),
    )

    if latest_residual is None or abs(latest_residual) <= residual_tolerance:
        return OORGateResult(
            signature=signature,
            status=OORGateStatus.NOT_OOR,
            candidate_oor=False,
            persistence_score=persistence_score,
            latest_residual=latest_residual,
            independent_constraint=True,
            constraint_id=constraint_id,
            reasons=(
                "The residual has been driven to zero (within tolerance) "
                "despite the persistent blind spot diagnosis.",
            ),
        )

    if persistence_score < min_persistence:
        return OORGateResult(
            signature=signature,
            status=OORGateStatus.NOT_OOR,
            candidate_oor=False,
            persistence_score=persistence_score,
            latest_residual=latest_residual,
            independent_constraint=True,
            constraint_id=constraint_id,
            reasons=(
                "Persistence is below the OOR threshold despite the "
                "diagnostic state and independent constraint.",
            ),
        )

    return OORGateResult(
        signature=signature,
        status=OORGateStatus.CANDIDATE_OOR,
        candidate_oor=True,
        persistence_score=persistence_score,
        latest_residual=latest_residual,
        independent_constraint=True,
        constraint_id=constraint_id,
        reasons=(
            "The error trajectory has reached a persistent blind spot.",
            "An independent constraint corroborates the persistent error.",
            "The residual remains non-zero across model generations.",
            "Persistence meets the OOR threshold.",
            "Eligible for future Z_D generation.",
        ),
    )


def review_history_for_oor(
    trajectories: Sequence[ErrorTrajectory],
    assessments: Mapping[ErrorSignature, DiagnosticAssessment],
    *,
    independent_constraints: Mapping[ErrorSignature, bool],
    constraint_ids: Optional[Mapping[ErrorSignature, str]] = None,
    min_persistence: float = 0.5,
    min_occurrences_for_full_persistence: int = 2,
    residual_tolerance: float = 0.0,
) -> list[OORGateResult]:
    """Review all trajectories in a model history through the OOR gate.

    Convenience wrapper that applies ``review_trajectory_for_oor`` to
    every trajectory, using per-signature independent constraints.  This
    is the natural downstream consumer of ``ModelHistory.assess()``.
    """
    constraint_ids = constraint_ids or {}
    results: list[OORGateResult] = []
    for trajectory in trajectories:
        assessment = assessments.get(trajectory.signature)
        if assessment is None:
            continue
        constraint = independent_constraints.get(trajectory.signature, False)
        cid = constraint_ids.get(trajectory.signature, "")
        results.append(
            review_trajectory_for_oor(
                trajectory,
                assessment,
                independent_constraint=constraint,
                constraint_id=cid,
                min_persistence=min_persistence,
                min_occurrences_for_full_persistence=min_occurrences_for_full_persistence,
                residual_tolerance=residual_tolerance,
            )
        )
    return results
