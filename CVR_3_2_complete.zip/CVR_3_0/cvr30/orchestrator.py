"""Revision/evaluation orchestrator for CVR 3.2.

This module implements the explicit revision loop:

    M_t -> prediction -> DOOR diagnosis -> accommodation
        -> prospective evaluation -> record generation -> M_{t+1}

It coordinates the existing episode, diagnostic, and model primitives
without becoming a centralized revision engine.  The scientific
decisions -- how to classify errors, how to accommodate them, how to
score adequacy, and how to construct the surviving next model -- are
injected as callables so the orchestrator stays a coordination
boundary rather than an embedded policy.

The OOR gate and Z_D generation remain deliberately downstream.  The
orchestrator does not import or invoke ``cvr30.oor``, ``cvr30.gate``,
or ``cvr30.pilot``.
"""
from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Mapping, Optional, Sequence

from .diagnostic import (
    AccommodationRecord,
    ErrorSignature,
    ModelGeneration,
    ModelHistory,
    error_signature_from_episode,
)
from .episode import EarningsEpisode
from .provenance import assert_no_future_leakage
from .types import ErrorKind, Outcome, Prediction


# -- Diagnosis descriptors ---------------------------------------------------

@dataclass(frozen=True)
class DoorDiagnosis:
    """Structural classification of one episode's prediction error.

    These are the same fields ``error_signature_from_episode`` consumes,
    so a diagnosis flows directly into a diagnostic error signature
    without a second translation step.
    """

    kind: ErrorKind = ErrorKind.UNKNOWN
    location: str = ""
    context_features: tuple[str, ...] = ()
    relational_features: tuple[str, ...] = ()
    structural_features: tuple[str, ...] = ()


@dataclass(frozen=True)
class DiagnosedError:
    """A residual paired with its structural diagnosis."""

    episode_id: str
    signature: ErrorSignature
    residual: float
    diagnosis: DoorDiagnosis


# -- Injected component protocols -------------------------------------------

DiagnosticClassifier = Callable[
    [EarningsEpisode, float, Any, ModelHistory],
    DoorDiagnosis,
]
"""Classify the prediction error of one episode.

Receives the episode, the residual (realized - predicted), the current
model object, and the model history.  Returns a structural diagnosis
that flows into the error signature.
"""

AccommodationPolicy = Callable[
    [Any, Sequence[EarningsEpisode], Sequence[DiagnosedError], ModelHistory],
    Sequence[AccommodationRecord],
]
"""Decide what accommodation records to attach to this generation.

Receives the current model, the evaluated episodes, the diagnosed
errors, and the model history.  Returns accommodation records whose
signatures should match the diagnosed error families.
"""

ProspectiveEvaluator = Callable[
    [Any, Sequence[EarningsEpisode], Sequence[DiagnosedError], Sequence[AccommodationRecord], ModelHistory],
    float,
]
"""Score the current model's adequacy on the completed episodes.

The score is model-level and caller-defined -- CVR 3.2 does not equate
single-episode accuracy with the model's domain of adequacy.  The
accommodation records are available so the evaluator can account for
the effect of planned revisions.
"""

SurvivorConstructor = Callable[
    [Any, Sequence[EarningsEpisode], Sequence[DiagnosedError], Sequence[AccommodationRecord], float, ModelHistory],
    Any,
]
"""Construct the next model M_{t+1} from the completed cycle.

The returned object only needs a ``model_id`` attribute and a
``predict(row)`` method if it will be used as the current model in a
subsequent cycle.
"""


# -- Cycle result -----------------------------------------------------------

@dataclass(frozen=True)
class RevisionCycleResult:
    """Boundary outputs of one orchestrated revision cycle."""

    current_model_id: str
    next_model: Any
    episodes: tuple[EarningsEpisode, ...]
    diagnosed_errors: tuple[DiagnosedError, ...]
    accommodations: tuple[AccommodationRecord, ...]
    adequacy_score: float
    generation: ModelGeneration


# -- Orchestrator -----------------------------------------------------------

@dataclass
class RevisionOrchestrator:
    """Coordinate one CVR revision cycle over completed episodes.

    The orchestrator is a thin coordinator: it produces predictions
    from the current model, classifies residuals, evaluates adequacy,
    records the completed generation into ``ModelHistory``, and
    constructs the surviving next model.  It does not invoke the OOR
    gate or the causal-status gate.
    """

    history: ModelHistory
    classifier: DiagnosticClassifier
    accommodation_policy: AccommodationPolicy
    evaluator: ProspectiveEvaluator
    survivor_constructor: SurvivorConstructor
    default_target: str = "outcome"
    default_horizon: str = "event"
    enforce_no_future_leakage: bool = True

    def run_cycle(
        self,
        current_model: Any,
        episodes: Sequence[EarningsEpisode],
        *,
        metadata: Optional[Mapping[str, object]] = None,
    ) -> RevisionCycleResult:
        """Run one revision cycle and record the completed generation.

        The current model's predictions are evaluated against realized
        outcomes, errors are diagnosed, adequacy is scored, and the
        resulting generation is recorded into ``ModelHistory``.  The
        next model is constructed by the injected survivor constructor.
        """
        if not episodes:
            raise ValueError("at least one completed episode is required")

        predicted_episodes = self._predict_episodes(current_model, episodes)
        diagnosed = self._diagnose_errors(current_model, predicted_episodes)
        accommodations = tuple(
            self.accommodation_policy(
                current_model, predicted_episodes, diagnosed, self.history
            )
        )
        adequacy = float(
            self.evaluator(
                current_model, predicted_episodes, diagnosed, accommodations, self.history
            )
        )
        next_model = self.survivor_constructor(
            current_model,
            predicted_episodes,
            diagnosed,
            accommodations,
            adequacy,
            self.history,
        )

        classifications: dict[str, ErrorKind] = {}
        locations: dict[str, str] = {}
        context_features: dict[str, tuple[str, ...]] = {}
        relational_features: dict[str, tuple[str, ...]] = {}
        structural_features: dict[str, tuple[str, ...]] = {}
        for error in diagnosed:
            eid = error.episode_id
            classifications[eid] = error.diagnosis.kind
            locations[eid] = error.diagnosis.location
            context_features[eid] = error.diagnosis.context_features
            relational_features[eid] = error.diagnosis.relational_features
            structural_features[eid] = error.diagnosis.structural_features

        record_metadata: dict[str, object] = {
            "next_model_id": getattr(next_model, "model_id", None),
            "diagnosed_error_count": len(diagnosed),
            "accommodation_count": len(accommodations),
        }
        if metadata:
            record_metadata.update(metadata)

        generation = self.history.record_generation(
            model_id=current_model.model_id,
            adequacy_score=adequacy,
            episodes=predicted_episodes,
            classifications=classifications,
            locations=locations,
            context_features=context_features,
            relational_features=relational_features,
            structural_features=structural_features,
            accommodations=accommodations,
            metadata=record_metadata,
        )

        return RevisionCycleResult(
            current_model_id=current_model.model_id,
            next_model=next_model,
            episodes=predicted_episodes,
            diagnosed_errors=diagnosed,
            accommodations=accommodations,
            adequacy_score=adequacy,
            generation=generation,
        )

    # -- internal steps -----------------------------------------------------

    def _predict_episodes(
        self,
        model: Any,
        episodes: Sequence[EarningsEpisode],
    ) -> tuple[EarningsEpisode, ...]:
        """Attach model predictions to completed episodes.

        Predictions use only frozen W0 evidence.  Episodes lacking a
        realized outcome are rejected because a residual cannot be
        computed without one.
        """
        predicted: list[EarningsEpisode] = []
        for episode in episodes:
            if episode.outcome is None:
                raise ValueError(
                    f"episode {episode.episode_id} has no realized outcome; "
                    "only completed episodes can be revised"
                )
            if self.enforce_no_future_leakage:
                assert_no_future_leakage(episode.evidence, episode.w0_boundary)

            row = episode.feature_dict()
            predicted_value = float(model.predict(row))
            prediction = Prediction(
                episode_id=episode.episode_id,
                predicted=predicted_value,
                target=episode.outcome.target,
                horizon=self.default_horizon,
                model_id=model.model_id,
                created_at=episode.w0_boundary,
                information_boundary=episode.w0_boundary,
                inputs=dict(row),
            )
            predicted.append(dataclasses.replace(episode, prediction=prediction))
        return tuple(predicted)

    def _diagnose_errors(
        self,
        model: Any,
        episodes: Sequence[EarningsEpisode],
    ) -> tuple[DiagnosedError, ...]:
        """Compute residuals and classify them structurally.

        Episodes whose prediction or outcome is missing are skipped
        rather than raising -- the prediction step already guarantees
        both are present for episodes that reach this method, but the
        guard keeps the diagnosis step independently safe.
        """
        diagnosed: list[DiagnosedError] = []
        for episode in episodes:
            if episode.prediction is None or episode.outcome is None:
                continue
            residual = float(episode.outcome.realized - episode.prediction.predicted)
            diagnosis = self.classifier(episode, residual, model, self.history)
            record = error_signature_from_episode(
                episode,
                kind=diagnosis.kind,
                location=diagnosis.location,
                context_features=diagnosis.context_features,
                relational_features=diagnosis.relational_features,
                structural_features=diagnosis.structural_features,
            )
            if record is None:
                continue
            signature, _ = record
            diagnosed.append(
                DiagnosedError(
                    episode_id=episode.episode_id,
                    signature=signature,
                    residual=residual,
                    diagnosis=diagnosis,
                )
            )
        return tuple(diagnosed)


# -- Convenience helpers for tests and demos ---------------------------------

def inverse_rmse_adequacy(
    model: Any,
    episodes: Sequence[EarningsEpisode],
    diagnosed: Sequence[DiagnosedError],
    accommodations: Sequence[AccommodationRecord],
    history: ModelHistory,
) -> float:
    """A simple adequacy score: 1 / (1 + RMSE of residuals).

    This is NOT the CVR adequacy definition.  It is a test/demo helper
    that produces a monotonically improving score as residuals shrink.
    The real adequacy score should come from a validated evaluation
    procedure.
    """
    if not diagnosed:
        return 1.0
    mse = sum(e.residual ** 2 for e in diagnosed) / len(diagnosed)
    rmse = mse ** 0.5
    return 1.0 / (1.0 + rmse)
