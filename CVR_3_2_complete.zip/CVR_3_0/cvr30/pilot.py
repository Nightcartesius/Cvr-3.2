from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence

from .ablation import AblationResult, ablate
from .discrimination import DiscriminationResult
from .gate import GateThresholds, causal_status_gate
from .models import LinearModel
from .necessity import NecessityResult, counterfactual_necessity, remove_candidate
from .rivals import RivalResult, compare_rivals
from .stability import StabilityResult, cross_instance_stability
from .types import CandidateResult


@dataclass(frozen=True)
class PilotReport:
    candidate: CandidateResult
    ablation: AblationResult
    necessity: NecessityResult
    stability: StabilityResult
    rivals: tuple[RivalResult, ...]


def run_candidate_pilot(
    candidate_id: str,
    rows: Sequence[Mapping[str, float]],
    actual: Sequence[float],
    full_model: LinearModel,
    baseline_model: LinearModel,
    counterfactual_worlds: Sequence[Mapping[str, float]],
    resolution,
    rival_effects: Mapping[str, Sequence[float]] | None = None,
    discrimination: DiscriminationResult | None = None,
    thresholds: GateThresholds = GateThresholds(),
) -> PilotReport:
    full_predict = full_model.predict
    baseline_predict = baseline_model.predict

    ab = ablate(
        candidate_id,
        rows,
        actual,
        full_predict,
        baseline_predict,
    )

    nec = counterfactual_necessity(
        candidate_id,
        counterfactual_worlds,
        resolution,
        lambda w: remove_candidate(candidate_id, w),
    )

    # In the pilot this is deliberately descriptive: it measures transfer of
    # the candidate's estimated effect, not a causal guarantee.
    effects = []
    for row in rows:
        effects.append(
            full_model.predict(row) - baseline_model.predict(
                remove_candidate(candidate_id, row)
            )
        )
    stab = cross_instance_stability(candidate_id, effects)

    result = causal_status_gate(
        candidate_id,
        ablation=ab,
        necessity=nec,
        stability=stab,
        discrimination=discrimination,
        thresholds=thresholds,
    )

    rivals = tuple(compare_rivals(rival_effects or {}))
    return PilotReport(result, ab, nec, stab, rivals)
