from __future__ import annotations

from datetime import datetime
from typing import Iterable

from .types import Evidence


def freeze_evidence(
    evidence: Iterable[Evidence],
    boundary: datetime,
) -> dict[str, Evidence]:
    """Return only evidence admissible at the frozen W0 boundary."""
    result = {}
    for item in evidence:
        if item.available_at(boundary):
            result[item.key] = item
    return result


def reject_future_leakage(
    evidence: Iterable[Evidence],
    boundary: datetime,
) -> list[str]:
    """Return keys that would leak information across the W0 boundary."""
    return [item.key for item in evidence if not item.available_at(boundary)]


def assert_no_future_leakage(
    evidence: Iterable[Evidence],
    boundary: datetime,
) -> None:
    leaked = reject_future_leakage(evidence, boundary)
    if leaked:
        raise ValueError(
            f"W0 leakage detected for evidence keys: {', '.join(sorted(leaked))}"
        )
