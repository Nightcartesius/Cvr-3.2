from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence


@dataclass(frozen=True)
class RivalResult:
    candidate_id: str
    mean_effect: float
    stability: float
    evidence_count: int


def compare_rivals(
    effects_by_candidate: Mapping[str, Sequence[float]],
) -> list[RivalResult]:
    """Return descriptive rival evidence only; do not rank candidates as a
    normative 'winner'."""
    result = []
    for candidate, effects in effects_by_candidate.items():
        vals = list(effects)
        if not vals:
            result.append(RivalResult(candidate, 0.0, 0.0, 0))
            continue
        signs = [1 if x > 0 else -1 if x < 0 else 0 for x in vals]
        nonzero = [s for s in signs if s]
        stability = (
            sum(s == nonzero[0] for s in nonzero) / len(nonzero)
            if nonzero
            else 0.0
        )
        result.append(RivalResult(candidate, sum(vals) / len(vals), stability, len(vals)))
    return result
