from __future__ import annotations

from dataclasses import dataclass
from math import isclose
from statistics import mean, pstdev
from typing import Iterable, Sequence


@dataclass(frozen=True)
class StabilityResult:
    candidate_id: str
    effects: tuple[float, ...]
    mean_effect: float
    dispersion: float
    stable_sign: bool
    transfer_count: int


def cross_instance_stability(
    candidate_id: str,
    effects: Sequence[float],
    tolerance: float = 0.0,
) -> StabilityResult:
    if not effects:
        return StabilityResult(candidate_id, (), 0.0, 0.0, False, 0)
    signs = [1 if x > tolerance else -1 if x < -tolerance else 0 for x in effects]
    nonzero = [s for s in signs if s]
    stable = bool(nonzero) and len(set(nonzero)) == 1
    return StabilityResult(
        candidate_id=candidate_id,
        effects=tuple(effects),
        mean_effect=mean(effects),
        dispersion=pstdev(effects) if len(effects) > 1 else 0.0,
        stable_sign=stable,
        transfer_count=len(effects),
    )
