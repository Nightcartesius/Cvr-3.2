from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Mapping, Optional


class EvidenceStatus(str, Enum):
    OBSERVED = "observed"
    DERIVED = "derived"
    HYPOTHESIS = "hypothesis"
    COUNTERFACTUAL = "counterfactual"
    EVALUATION_ONLY = "evaluation_only"
    UNKNOWN = "unknown"


class CausalStatus(str, Enum):
    SUPPORTED_CANDIDATE = "supported_candidate"
    MODERATE_PROVISIONAL = "moderate_provisional"
    INCONCLUSIVE = "inconclusive"
    REJECTED_CANDIDATE = "rejected_candidate"
    INSUFFICIENT_DATA = "insufficient_data"


class ErrorKind(str, Enum):
    OBSERVATION = "observation_error"
    PARAMETER = "parameter_error"
    RELATIONAL = "relational_error"
    CONTEXT = "context_error"
    STRUCTURAL = "structural_error"
    INTERACTION = "interaction_error"
    CAUSAL_STRUCTURAL = "causal_structural_error"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class Provenance:
    source_id: str
    observed_at: datetime
    valid_from: Optional[datetime] = None
    valid_to: Optional[datetime] = None
    status: EvidenceStatus = EvidenceStatus.OBSERVED
    notes: str = ""

    def available_at(self, boundary: datetime) -> bool:
        if self.observed_at > boundary:
            return False
        if self.valid_from is not None and self.valid_from > boundary:
            return False
        if self.valid_to is not None and self.valid_to < boundary:
            return False
        return True


@dataclass(frozen=True)
class Evidence:
    key: str
    value: Any
    provenance: Provenance

    def available_at(self, boundary: datetime) -> bool:
        return self.provenance.available_at(boundary)


@dataclass
class Prediction:
    episode_id: str
    predicted: float
    target: str
    horizon: str
    model_id: str
    created_at: datetime
    information_boundary: datetime
    inputs: Mapping[str, Any] = field(default_factory=dict)


@dataclass
class Outcome:
    episode_id: str
    realized: float
    target: str
    observed_at: datetime
    benchmark_realized: Optional[float] = None

    @property
    def abnormal(self) -> Optional[float]:
        if self.benchmark_realized is None:
            return None
        return self.realized - self.benchmark_realized


@dataclass
class ErrorDiagnosis:
    error: float
    normalized_error: Optional[float]
    kind: ErrorKind
    persistence: float
    notes: str = ""


@dataclass
class CandidateResult:
    candidate_id: str
    status: CausalStatus
    score: float
    evidence: Mapping[str, Any]
    reasons: list[str] = field(default_factory=list)
