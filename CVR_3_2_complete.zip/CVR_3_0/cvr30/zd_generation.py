"""Z_D candidate generation downstream of the OOR gate.

This module implements the final step in the CVR 3.2 diagnostic chain:

    ModelHistory / trajectories
        -> persistent blind spot diagnostic state
        -> OOR gate (with independent constraint)
        -> Z_D candidate specification
        -> future causal-candidate testing (ablation, necessity, etc.)

When the OOR gate declares a candidate OOR (``eligible_for_zd_generation``
is True), this module produces a ``ZDCandidateSpec`` describing a
proposed explanatory variable that could resolve the persistent
out-of-adequacy residual.

This is **candidate generation**, not causal discovery.  The generated
specification is explicitly unvalidated.  It does not claim causal
support, it does not run the causal-status gate, and it does not
promote ``Z_D`` to truth.  The spec is designed to be consumed by the
existing causal-candidate testing pipeline (``run_candidate_pilot``)
when appropriate evidence is available.

The module does not import or invoke ``cvr30.pilot`` or ``cvr30.gate``.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Mapping, Optional, Sequence

from .diagnostic import ErrorSignature
from .oor import OORGateResult


# -- Proposal status --------------------------------------------------------

class ZDProposalStatus(str, Enum):
    """Whether a Z_D candidate was generated from an OOR gate result."""

    NOT_ELIGIBLE = "not_eligible"
    PROPOSED = "proposed"


# -- Measurement requirements -----------------------------------------------

@dataclass(frozen=True)
class ZDMeasurementRequirement:
    """A measurement needed to construct or evaluate the Z_D candidate.

    Each requirement specifies what to measure, whether point-in-time
    evidence is required (to respect the W0 leakage boundary), and what
    sources are acceptable.  This is the contract the evidence layer
    must satisfy before the candidate can be tested.
    """

    name: str
    description: str
    point_in_time_required: bool = True
    acceptable_sources: tuple[str, ...] = ()
    leakage_risk: str = ""


# -- Candidate specification ------------------------------------------------

@dataclass(frozen=True)
class ZDCandidateSpec:
    """Specification of a proposed Z_D candidate variable.

    This is the output of Z_D generation.  It is a proposal, not a
    validated cause.  The spec carries enough structure for the existing
    causal-candidate testing pipeline to consume it (``candidate_id``
    matches what ``run_candidate_pilot`` expects), but it does not
    claim any ``CausalStatus`` and does not contain a ``CandidateResult``.
    """

    candidate_id: str
    label: str
    hypothesis: str
    source_signature: ErrorSignature
    source_constraint_id: str = ""
    status: ZDProposalStatus = ZDProposalStatus.PROPOSED
    required_measurements: tuple[ZDMeasurementRequirement, ...] = ()
    construction_notes: tuple[str, ...] = ()
    validation_plan: tuple[str, ...] = ()
    metadata: Mapping[str, object] = field(
        default_factory=dict, compare=False, repr=False
    )

    @property
    def oor_constraint_id(self) -> str:
        """The independent constraint that opened the OOR gate."""
        return self.source_constraint_id


# -- Generation result ------------------------------------------------------

@dataclass(frozen=True)
class ZDGenerationResult:
    """Result of Z_D candidate generation from one OOR gate result."""

    status: ZDProposalStatus
    candidate: Optional[ZDCandidateSpec]
    reasons: tuple[str, ...] = ()


# -- Strategy callable ------------------------------------------------------

ZDProposalStrategy = Callable[[OORGateResult], ZDCandidateSpec]
"""A callable that produces a Z_D candidate spec from an OOR gate result.

This allows future users to generate non-default Z_D candidates from
the same OOR result without hardcoding automatic discovery.  The
strategy receives the full ``OORGateResult`` and must return a
``ZDCandidateSpec``.
"""


# -- Default measurement requirements ---------------------------------------

def _default_measurement_requirements() -> tuple[ZDMeasurementRequirement, ...]:
    """The canonical measurement requirements for the default Z_D hypothesis.

    Z_D = pre-event expectation revision / expectation-state revision.
    Constructing this variable requires a pre-event expectation
    estimate, a prior baseline, and a W0-boundary timestamp.  The
    realized outcome is allowed only at evaluation time, never during
    construction.
    """
    return (
        ZDMeasurementRequirement(
            name="pre_event_expectation",
            description=(
                "The analyst or market expectation of the outcome as "
                "observed before the W0 information boundary."
            ),
            point_in_time_required=True,
            acceptable_sources=("analyst_consensus_pre_event", "point_in_time_estimate"),
            leakage_risk=(
                "An event-time consensus number is not silently treated "
                "as a reconstructed pre-event revision path."
            ),
        ),
        ZDMeasurementRequirement(
            name="prior_expectation_baseline",
            description=(
                "The expectation state against which the pre-event "
                "revision is measured."
            ),
            point_in_time_required=True,
            acceptable_sources=("prior_consensus", "model_baseline"),
        ),
        ZDMeasurementRequirement(
            name="w0_boundary_timestamp",
            description=(
                "The frozen information boundary that separates "
                "admissible pre-event evidence from the realized outcome."
            ),
            point_in_time_required=True,
            acceptable_sources=("event_timestamp", "disclosure_timestamp"),
        ),
        ZDMeasurementRequirement(
            name="realized_outcome",
            description=(
                "The realized outcome, used only at evaluation time. "
                "Must not enter the candidate's construction."
            ),
            point_in_time_required=False,
            acceptable_sources=("post_event_observation",),
            leakage_risk=(
                "Including the realized outcome in the candidate's "
                "explanatory inputs would violate the W0 leakage rule."
            ),
        ),
    )


def _default_validation_plan() -> tuple[str, ...]:
    """The validation plan that the causal-candidate testing pipeline should run.

    These are the existing tests from the CVR 3.0 causal-candidate
    machinery.  They are listed here as a plan, not executed.
    """
    return (
        "Ablation: does removing Z_D from the model increase prediction error?",
        "Necessity: does the outcome fail when Z_D is removed in counterfactual worlds?",
        "Stability: does Z_D's effect have a consistent sign across instances?",
        "Discrimination: is Z_D specific to the hypothesized cause versus rivals?",
        "Causal-status gate: weigh ablation, necessity, stability, and discrimination.",
    )


def _default_construction_notes() -> tuple[str, ...]:
    return (
        "Z_D is constructed from pre-event evidence only.",
        "The realized outcome enters only at evaluation time.",
        "The candidate is a proposal from the OOR gate, not a confirmed cause.",
    )


# -- Primary generation function --------------------------------------------

def generate_zd_candidate(
    oor_result: OORGateResult,
    *,
    candidate_id: str = "Z_D",
    label: str = "pre-event expectation revision / expectation-state revision",
    hypothesis: str = (
        "A pre-event expectation-state revision explains the persistent "
        "out-of-adequacy residual."
    ),
    required_measurements: Optional[Sequence[ZDMeasurementRequirement]] = None,
    construction_notes: Sequence[str] = (),
    validation_plan: Sequence[str] = (),
    metadata: Optional[Mapping[str, object]] = None,
) -> ZDGenerationResult:
    """Generate a Z_D candidate specification from an OOR gate result.

    When the OOR gate has declared a candidate OOR
    (``eligible_for_zd_generation`` is True), this function produces a
    ``ZDCandidateSpec`` describing the proposed explanatory variable.

    When the OOR gate has not opened (``eligible_for_zd_generation`` is
    False), no candidate is generated and the status is
    ``NOT_ELIGIBLE``.

    This is candidate generation, not causal discovery.  The returned
    spec is explicitly unvalidated and must be tested through the
    existing causal-candidate pipeline before any causal claim is made.
    """
    if not oor_result.eligible_for_zd_generation:
        return ZDGenerationResult(
            status=ZDProposalStatus.NOT_ELIGIBLE,
            candidate=None,
            reasons=(
                "The OOR gate has not opened: the trajectory is not "
                "eligible for Z_D generation.",
                f"OOR gate status: {oor_result.status.value}.",
            ),
        )

    measurements = tuple(required_measurements) if required_measurements is not None else _default_measurement_requirements()
    notes = tuple(construction_notes) if construction_notes else _default_construction_notes()
    plan = tuple(validation_plan) if validation_plan else _default_validation_plan()

    candidate_metadata: dict[str, object] = {
        "source_oor_status": oor_result.status.value,
        "source_constraint_id": oor_result.constraint_id,
        "latest_residual": oor_result.latest_residual,
        "persistence_score": oor_result.persistence_score,
        "independent_constraint": oor_result.independent_constraint,
    }
    if metadata:
        candidate_metadata.update(metadata)

    candidate = ZDCandidateSpec(
        candidate_id=candidate_id,
        label=label,
        hypothesis=hypothesis,
        source_signature=oor_result.signature,
        source_constraint_id=oor_result.constraint_id,
        status=ZDProposalStatus.PROPOSED,
        required_measurements=measurements,
        construction_notes=notes,
        validation_plan=plan,
        metadata=candidate_metadata,
    )

    return ZDGenerationResult(
        status=ZDProposalStatus.PROPOSED,
        candidate=candidate,
        reasons=(
            "The OOR gate declared a candidate OOR with an independent constraint.",
            f"The persistent error family is: {oor_result.signature.kind.value} "
            f"on target '{oor_result.signature.target}'.",
            "A Z_D candidate has been proposed but not validated.",
            "Run the causal-candidate testing pipeline before making any causal claim.",
        ),
    )


def generate_zd_candidate_with_strategy(
    oor_result: OORGateResult,
    strategy: ZDProposalStrategy,
) -> ZDGenerationResult:
    """Generate a Z_D candidate using an injected proposal strategy.

    The strategy receives the full ``OORGateResult`` and returns a
    ``ZDCandidateSpec``.  This allows callers to generate non-default
    Z_D candidates (e.g., different variable constructions, different
    measurement requirements) without modifying this module.

    If the OOR gate has not opened, no candidate is generated regardless
    of the strategy.
    """
    if not oor_result.eligible_for_zd_generation:
        return ZDGenerationResult(
            status=ZDProposalStatus.NOT_ELIGIBLE,
            candidate=None,
            reasons=(
                "The OOR gate has not opened: the trajectory is not "
                "eligible for Z_D generation.",
                f"OOR gate status: {oor_result.status.value}.",
            ),
        )

    candidate = strategy(oor_result)
    return ZDGenerationResult(
        status=ZDProposalStatus.PROPOSED,
        candidate=candidate,
        reasons=(
            "A Z_D candidate was generated via the injected strategy.",
            "The candidate has not been validated by the causal-candidate testing pipeline.",
        ),
    )


# -- Pilot handoff helper ---------------------------------------------------

def pilot_candidate_id(result: ZDGenerationResult) -> Optional[str]:
    """Extract the candidate ID for use with ``run_candidate_pilot``.

    Returns ``None`` if no candidate was generated.  This helper does
    not invoke the pilot; it only provides the ID the caller would pass
    to ``run_candidate_pilot(candidate_id=...)``.
    """
    return result.candidate.candidate_id if result.candidate is not None else None
