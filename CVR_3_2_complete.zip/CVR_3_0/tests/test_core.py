import unittest
from datetime import datetime, timezone

from cvr30.ablation import do_not_candidate
from cvr30.accessibility import World, epistemic_invariance
from cvr30.necessity import counterfactual_necessity
from cvr30.provenance import reject_future_leakage
from cvr30.types import Evidence, Provenance, EvidenceStatus


class TestCore(unittest.TestCase):
    def test_w0_rejects_future(self):
        t0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
        t1 = datetime(2026, 1, 2, tzinfo=timezone.utc)
        items = [
            Evidence("x", 1, Provenance("pre", t0, status=EvidenceStatus.OBSERVED)),
            Evidence("y", 2, Provenance("post", t1, status=EvidenceStatus.OBSERVED)),
        ]
        self.assertEqual(reject_future_leakage(items, t0), ["y"])

    def test_intervention_removes_candidate(self):
        row = {"Z_D": 4.0, "x": 2.0}
        out = do_not_candidate(row, "Z_D")
        self.assertEqual(out["Z_D"], 0.0)
        self.assertEqual(out["x"], 2.0)

    def test_necessity(self):
        worlds = [
            {"Z_D": 1.0, "E": 1.0},
            {"Z_D": 2.0, "E": 1.0},
            {"Z_D": 3.0, "E": 1.0},
        ]
        result = counterfactual_necessity(
            "Z_D",
            worlds,
            lambda w: w["E"] == 1.0 and w["Z_D"] != 0.0,
            lambda w: {**w, "Z_D": 0.0},
        )
        self.assertEqual(result.necessity_rate, 1.0)
        self.assertTrue(result.resistant)

    def test_invariance(self):
        worlds = [
            World("1", {"p": True}),
            World("2", {"p": True}),
        ]
        self.assertTrue(epistemic_invariance(worlds, lambda s: s["p"]))


if __name__ == "__main__":
    unittest.main()
