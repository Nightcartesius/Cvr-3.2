import unittest

from datetime import datetime, timezone

from cvr30.diagnostic import (
    AccommodationRecord,
    DiagnosticStatus,
    ErrorSignature,
    ModelGeneration,
    assess_trajectory,
    build_adequacy_profile,
    error_signature_from_episode,
    model_generation_from_episodes,
    build_trajectory,
)
from cvr30.episode import EarningsEpisode
from cvr30.types import ErrorKind, Outcome, Prediction


class TestDiagnostic32(unittest.TestCase):
    def setUp(self):
        self.signature = ErrorSignature(
            kind=ErrorKind.STRUCTURAL,
            target="y",
            location="event",
            direction=1,
            structural_features=("gravity_rule",),
        )

    def generation(self, model_id, adequacy, residual, accommodations=()):
        parent = None if model_id == "M0" else f"M{int(model_id[1:]) - 1}"
        return ModelGeneration(
            model_id=model_id,
            parent_model_id=parent,
            adequacy_score=adequacy,
            errors=((self.signature, residual),),
            accommodations=tuple(accommodations),
        )

    def test_a_ordinary_error(self):
        generations = [self.generation("M0", 0.50, 1.0)]
        trajectory = build_trajectory(self.signature, generations)
        assessment = assess_trajectory(trajectory)

        self.assertEqual(assessment.status, DiagnosticStatus.ORDINARY_ERROR)
        self.assertFalse(assessment.persistent)
        self.assertFalse(assessment.eligible_for_oor_review)

    def test_b_successful_accommodation(self):
        accommodation = AccommodationRecord(
            generation_id="M1",
            signature=self.signature,
            accommodation_type="parameter",
            prospective_improvement=0.20,
            heldout_improvement=0.10,
            status="successful",
        )
        generations = [
            self.generation("M0", 0.50, 1.0),
            self.generation("M1", 0.70, 0.2, (accommodation,)),
        ]
        trajectory = build_trajectory(self.signature, generations)
        assessment = assess_trajectory(trajectory)

        self.assertEqual(assessment.status, DiagnosticStatus.CORRIGIBLE_ERROR)
        self.assertEqual(assessment.successful_accommodations, 1)
        self.assertFalse(assessment.eligible_for_oor_review)

    def test_c_recurrent_error_with_continuing_improvement(self):
        generations = [
            self.generation("M0", 0.50, 1.0),
            self.generation("M1", 0.65, 0.8),
            self.generation("M2", 0.78, 0.7),
            self.generation("M3", 0.90, 0.6),
        ]
        trajectory = build_trajectory(self.signature, generations)
        assessment = assess_trajectory(trajectory, dominant=False)

        self.assertEqual(assessment.status, DiagnosticStatus.RECURRENT_ERROR)
        self.assertTrue(assessment.persistent)
        self.assertTrue(assessment.diminishing_returns)
        self.assertFalse(assessment.eligible_for_oor_review)

    def test_d_diminishing_returns_plus_persistent_blind_spot(self):
        failed_accommodation = AccommodationRecord(
            generation_id="M2",
            signature=self.signature,
            accommodation_type="structural",
            prospective_improvement=0.0,
            status="failed",
        )
        generations = [
            self.generation("M0", 0.50, 1.0),
            self.generation("M1", 0.70, 0.9),
            self.generation("M2", 0.80, 0.85, (failed_accommodation,)),
            self.generation("M3", 0.84, 0.83),
        ]
        trajectory = build_trajectory(self.signature, generations)
        assessment = assess_trajectory(trajectory, dominant=True)

        self.assertEqual(assessment.status, DiagnosticStatus.PERSISTENT_BLIND_SPOT)
        self.assertTrue(assessment.persistent)
        self.assertTrue(assessment.diminishing_returns)
        self.assertTrue(assessment.limiting_residual)
        self.assertTrue(assessment.structural_non_accommodation)
        self.assertTrue(assessment.eligible_for_oor_review)

    def test_false_structural_alarm_without_dominance(self):
        generations = [
            self.generation("M0", 0.50, 1.0),
            self.generation("M1", 0.70, 0.9),
            self.generation("M2", 0.80, 0.85),
            self.generation("M3", 0.84, 0.83),
        ]
        trajectory = build_trajectory(self.signature, generations)
        assessment = assess_trajectory(trajectory, dominant=False)

        self.assertEqual(assessment.status, DiagnosticStatus.RECURRENT_ERROR)
        self.assertFalse(assessment.eligible_for_oor_review)

    def test_adequacy_profile(self):
        accommodation = AccommodationRecord(
            generation_id="M1",
            signature=self.signature,
            accommodation_type="context",
            prospective_improvement=0.10,
        )
        generations = [
            self.generation("M0", 0.50, 1.0),
            self.generation("M1", 0.60, 0.7, (accommodation,)),
        ]
        profile = build_adequacy_profile(generations)

        self.assertEqual(profile.latest_adequacy, 0.60)
        self.assertEqual(profile.accommodation_success_rate, 1.0)
        self.assertIn(ErrorKind.STRUCTURAL, profile.corrigible_error_kinds)

    def test_real_episode_adapter_preserves_prediction_outcome_boundary(self):
        t0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
        post = datetime(2026, 1, 2, tzinfo=timezone.utc)
        episode = EarningsEpisode(
            episode_id="E1",
            asset="TEST",
            event_time=t0,
            w0_boundary=t0,
            evidence=[],
            prediction=Prediction(
                episode_id="E1",
                predicted=0.01,
                target="next_session_return",
                horizon="1d",
                model_id="M0",
                created_at=t0,
                information_boundary=t0,
            ),
            outcome=Outcome(
                episode_id="E1",
                realized=-0.02,
                target="next_session_return",
                observed_at=post,
            ),
        )

        record = error_signature_from_episode(
            episode,
            kind=ErrorKind.CONTEXT,
            context_features=("macro_regime",),
        )
        self.assertIsNotNone(record)
        signature, residual = record
        self.assertEqual(residual, -0.03)
        self.assertEqual(signature.kind, ErrorKind.CONTEXT)
        self.assertEqual(signature.direction, -1)

        generation = model_generation_from_episodes(
            "M0", None, 0.50, [episode],
            classifications={"E1": ErrorKind.CONTEXT},
            context_features={"E1": ("macro_regime",)},
        )
        self.assertEqual(generation.model_id, "M0")
        self.assertEqual(len(generation.errors), 1)
        self.assertEqual(generation.errors[0][0].target, "next_session_return")
        self.assertEqual(generation.errors[0][1], -0.03)


if __name__ == "__main__":
    unittest.main()

class TestModelHistory(unittest.TestCase):
    def setUp(self):
        self.signature = ErrorSignature(
            kind=ErrorKind.STRUCTURAL,
            target="y",
            location="event",
            direction=1,
            structural_features=("gravity_rule",),
        )

    def generation(self, model_id, adequacy, residual):
        parent = None if model_id == "M0" else f"M{int(model_id[1:]) - 1}"
        return ModelGeneration(
            model_id=model_id,
            parent_model_id=parent,
            adequacy_score=adequacy,
            errors=((self.signature, residual),),
        )

    def test_history_enforces_lineage_and_tracks_improvement(self):
        from cvr30.diagnostic import ModelHistory

        history = ModelHistory()
        history.append(self.generation("M0", 0.50, 1.0))
        history.append(self.generation("M1", 0.70, 0.8))
        history.append(self.generation("M2", 0.80, 0.7))

        self.assertEqual(history.adequacy_history, (0.50, 0.70, 0.80))
        self.assertAlmostEqual(history.improvement_history[0], 0.20)
        self.assertAlmostEqual(history.improvement_history[1], 0.10)
        self.assertEqual(history.latest.model_id, "M2")

    def test_history_rejects_broken_lineage(self):
        from cvr30.diagnostic import ModelHistory

        history = ModelHistory()
        history.append(self.generation("M0", 0.50, 1.0))
        broken = ModelGeneration("M2", "M9", 0.70, ((self.signature, 0.8),))
        with self.assertRaises(ValueError):
            history.append(broken)

    def test_history_builds_real_trajectory_and_profile(self):
        from cvr30.diagnostic import ModelHistory

        history = ModelHistory()
        history.append(self.generation("M0", 0.50, 1.0))
        history.append(self.generation("M1", 0.70, 0.8))
        history.append(self.generation("M2", 0.78, 0.7))

        trajectories = history.trajectories()
        self.assertEqual(len(trajectories), 1)
        self.assertEqual(trajectories[0].occurrence_count, 3)
        self.assertTrue(trajectories[0].persistent)
        self.assertEqual(history.adequacy_profile().latest_adequacy, 0.78)

class TestIntegratedRevisionRecording(unittest.TestCase):
    def episode(self, episode_id, predicted, realized, model_id):
        t0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
        post = datetime(2026, 1, 2, tzinfo=timezone.utc)
        return EarningsEpisode(
            episode_id=episode_id,
            asset="TEST",
            event_time=t0,
            w0_boundary=t0,
            evidence=[],
            prediction=Prediction(
                episode_id=episode_id,
                predicted=predicted,
                target="next_session_return",
                horizon="1d",
                model_id=model_id,
                created_at=t0,
                information_boundary=t0,
            ),
            outcome=Outcome(
                episode_id=episode_id,
                realized=realized,
                target="next_session_return",
                observed_at=post,
            ),
        )

    def test_record_generation_auto_links_real_revisions(self):
        from cvr30.diagnostic import ModelHistory

        history = ModelHistory()
        e0 = self.episode("E0", 0.01, -0.02, "M0")
        e1 = self.episode("E1", 0.00, -0.01, "M1")

        g0 = history.record_generation(
            "M0", 0.50, [e0],
            classifications={"E0": ErrorKind.STRUCTURAL},
            structural_features={"E0": ("event_relation",)},
        )
        g1 = history.record_generation(
            "M1", 0.65, [e1],
            classifications={"E1": ErrorKind.STRUCTURAL},
            structural_features={"E1": ("event_relation",)},
            metadata={"revision_reason": "accommodation"},
        )

        self.assertIsNone(g0.parent_model_id)
        self.assertEqual(g1.parent_model_id, "M0")
        self.assertEqual(history.adequacy_history, (0.50, 0.65))
        self.assertEqual(history.latest.metadata["revision_reason"], "accommodation")
        self.assertEqual(len(history.trajectories()), 1)
        self.assertTrue(history.trajectories()[0].persistent)

    def test_record_generation_preserves_accommodation_history(self):
        from cvr30.diagnostic import ModelHistory

        history = ModelHistory()
        e0 = self.episode("E0", 0.01, -0.02, "M0")
        e1 = self.episode("E1", 0.01, -0.015, "M1")
        sig = ErrorSignature(
            kind=ErrorKind.STRUCTURAL,
            target="next_session_return",
            structural_features=("event_relation",),
            direction=-1,
        )
        accommodation = AccommodationRecord(
            generation_id="M1",
            signature=sig,
            accommodation_type="structural",
            prospective_improvement=0.15,
            heldout_improvement=0.05,
            status="successful",
        )

        history.record_generation(
            "M0", 0.50, [e0],
            classifications={"E0": ErrorKind.STRUCTURAL},
            structural_features={"E0": ("event_relation",)},
        )
        history.record_generation(
            "M1", 0.65, [e1],
            classifications={"E1": ErrorKind.STRUCTURAL},
            structural_features={"E1": ("event_relation",)},
            accommodations=(accommodation,),
        )

        trajectory = history.trajectories()[0]
        self.assertEqual(len(trajectory.accommodation_history), 1)
        self.assertTrue(trajectory.accommodation_history[0].improved)
