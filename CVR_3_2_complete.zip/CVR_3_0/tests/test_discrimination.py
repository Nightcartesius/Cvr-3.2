import unittest

from cvr30.ablation import AblationResult
from cvr30.discrimination import build_reference_population, discriminate, wilson_interval
from cvr30.gate import causal_status_gate, GateThresholds
from cvr30.necessity import NecessityResult
from cvr30.stability import StabilityResult
from cvr30.types import CausalStatus


class TestWilsonInterval(unittest.TestCase):
    def test_bounds_stay_within_unit_interval(self):
        lo, hi = wilson_interval(0, 5)
        self.assertGreaterEqual(lo, 0.0)
        self.assertLessEqual(hi, 1.0)

    def test_narrows_with_larger_n(self):
        lo_small, hi_small = wilson_interval(3, 4)
        lo_large, hi_large = wilson_interval(300, 400)
        self.assertGreater(hi_small - lo_small, hi_large - lo_large)

    def test_zero_n_returns_full_interval(self):
        self.assertEqual(wilson_interval(0, 0), (0.0, 1.0))


class TestBuildReferencePopulation(unittest.TestCase):
    def test_splits_on_named_fields(self):
        rows = [
            {"is_contradiction": True, "fever": True},
            {"is_contradiction": True, "fever": True},
            {"is_contradiction": False, "fever": True},
            {"is_contradiction": False, "fever": False},
            {"is_contradiction": False, "fever": False},
        ]
        cause_pop, control_pop = build_reference_population(
            rows, cause_field="is_contradiction", condition_field="fever"
        )
        self.assertEqual(cause_pop, [True, True])
        self.assertEqual(control_pop, [True, False, False])


class TestDiscriminate(unittest.TestCase):
    def test_fever_measles_pattern_is_a_weak_discriminator(self):
        # Fever: present in every measles case, but also common without it.
        cause_pop = [True, True, True, True]
        control_pop = [True, True, False, True, False, True, True, False]
        result = discriminate("fever", "measles_vs_general_population", cause_pop, control_pop)
        self.assertLess(result.likelihood_ratio_positive, 2.0)
        self.assertIn("fever/measles", result.interpretation.lower().replace("koplik", "fever"))

    def test_koplik_spots_pattern_is_a_strong_discriminator(self):
        # Rare outside measles, present in most measles cases.
        cause_pop = [True, True, True, False]
        control_pop = [False] * 20
        result = discriminate("koplik_spots", "measles_vs_general_population", cause_pop, control_pop)
        self.assertIsNone(result.likelihood_ratio_positive)  # zero control hits -> undefined, not infinite
        self.assertIn("undefined", result.interpretation.lower())

    def test_moderate_discriminator_with_nonzero_control_hits(self):
        cause_pop = [True] * 8 + [False] * 2
        control_pop = [True] * 2 + [False] * 18
        result = discriminate("z", "reference", cause_pop, control_pop)
        self.assertGreaterEqual(result.likelihood_ratio_positive, 2.0)
        self.assertLess(result.likelihood_ratio_positive, 10.0)

    def test_well_powered_flag(self):
        result = discriminate("z", "ref", [True, True], [False, False])
        self.assertFalse(result.well_powered)
        result2 = discriminate("z", "ref", [True] * 6, [False] * 6)
        self.assertTrue(result2.well_powered)


class TestGateWithDiscrimination(unittest.TestCase):
    def _strong_legacy_inputs(self):
        ab = AblationResult("Z_D", 1.0, 2.0, 1.0, True, "")
        ne = NecessityResult("Z_D", 4, 4, 1.0, True, "")
        st = StabilityResult("Z_D", (1.0, 1.0, 1.0, 1.0), 1.0, 0.0, True, 4)
        return ab, ne, st

    def test_weak_discrimination_vetoes_a_supported_candidate(self):
        ab, ne, st = self._strong_legacy_inputs()
        # Fever/measles-shaped: occurs constantly in the control population too.
        weak_disc = discriminate(
            "Z_D", "sector_vs_general",
            cause_population=[True, True, True, True, True, True],
            control_population=[True, True, True, False, True, True, True, False],
        )
        out = causal_status_gate(
            "Z_D", ablation=ab, necessity=ne, stability=st, discrimination=weak_disc
        )
        self.assertEqual(out.status, CausalStatus.INCONCLUSIVE)
        self.assertTrue(any("Downgraded" in r for r in out.reasons))

    def test_strong_discrimination_promotes_moderate_to_supported(self):
        ab = AblationResult("Z_D", 1.0, 1.4, 0.4, True, "")
        ne = NecessityResult("Z_D", 2, 3, 2 / 3, False, "")
        st = StabilityResult("Z_D", (1.0, 2.0, 0.5), 1.166, 0.62, True, 3)
        strong_disc = discriminate(
            "Z_D", "sector_vs_general",
            cause_population=[True] * 8,
            control_population=[True] + [False] * 19,
        )
        out = causal_status_gate(
            "Z_D", ablation=ab, necessity=ne, stability=st, discrimination=strong_disc
        )
        self.assertEqual(out.status, CausalStatus.SUPPORTED_CANDIDATE)
        self.assertTrue(any("Promoted" in r for r in out.reasons))

    def test_no_discrimination_falls_back_to_legacy_path(self):
        ab, ne, st = self._strong_legacy_inputs()
        out = causal_status_gate("Z_D", ablation=ab, necessity=ne, stability=st)
        self.assertEqual(out.status, CausalStatus.SUPPORTED_CANDIDATE)
        self.assertNotIn("reference_class", out.evidence)

    def test_underpowered_discrimination_compresses_score_toward_midpoint(self):
        ab, ne, st = self._strong_legacy_inputs()
        tiny_disc = discriminate(
            "Z_D", "sector_vs_general", cause_population=[True, True], control_population=[False, False]
        )
        out = causal_status_gate(
            "Z_D", ablation=ab, necessity=ne, stability=st, discrimination=tiny_disc
        )
        self.assertTrue(any("small on at least one side" in r for r in out.reasons))


if __name__ == "__main__":
    unittest.main()
