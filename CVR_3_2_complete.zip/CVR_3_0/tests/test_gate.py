import unittest

from cvr30.ablation import AblationResult
from cvr30.gate import causal_status_gate, GateThresholds
from cvr30.necessity import NecessityResult
from cvr30.stability import StabilityResult
from cvr30.types import CausalStatus


class TestGate(unittest.TestCase):
    def test_moderate_provisional(self):
        ab = AblationResult("Z_D", 1.0, 1.4, 0.4, True, "")
        ne = NecessityResult("Z_D", 2, 3, 2/3, False, "")
        st = StabilityResult("Z_D", (1.0, 2.0, 0.5), 1.166, 0.62, True, 3)

        out = causal_status_gate(
            "Z_D",
            ablation=ab,
            necessity=ne,
            stability=st,
            thresholds=GateThresholds(min_instances=3),
        )
        self.assertEqual(out.status, CausalStatus.MODERATE_PROVISIONAL)

    def test_insufficient_transfer(self):
        ab = AblationResult("Z_D", 1.0, 1.4, 0.4, True, "")
        ne = NecessityResult("Z_D", 2, 2, 1.0, True, "")
        st = StabilityResult("Z_D", (1.0,), 1.0, 0.0, True, 1)

        out = causal_status_gate(
            "Z_D",
            ablation=ab,
            necessity=ne,
            stability=st,
        )
        self.assertEqual(out.status, CausalStatus.INSUFFICIENT_DATA)


if __name__ == "__main__":
    unittest.main()
