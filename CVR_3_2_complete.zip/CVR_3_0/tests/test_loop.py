import unittest
from dataclasses import dataclass
from datetime import datetime, timezone

from cvr30.diagnostic import (
    AccommodationRecord,
    DiagnosticAssessment,
    DiagnosticStatus,
    ErrorSignature,
    ModelHistory,
)
from cvr30.episode import EarningsEpisode
from cvr30.loop import (
    IndependentConstraint,
    RevisionLoop,
    RevisionLoopStatus,
    batched_episode_provider,
    fixed_episode_provider,
    no_dominant_families,
    no_independent_constraints,
)
from cvr30.models import LinearModel
from cvr30.orchestrator import (
    DiagnosedError,
    DoorDiagnosis,
    RevisionOrchestrator,
    inverse_rmse_adequacy,
)
from cvr30.types import ErrorKind, Evidence, Outcome, Prediction, Provenance, EvidenceStatus


class _LoopFixture:
    """Shared fixtures for loop driver tests."""

    def __init__(self):
        self.t0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
        self.post = datetime(2026, 1, 2, tzinfo=timezone.utc)
        self.signature = ErrorSignature(
            kind=ErrorKind.STRUCTURAL,
            target="next_session_return",
            structural_features=("event_relation",),
            direction=-1,
        )

    def episode(self, episode_id, feature_value, realized):
        return EarningsEpisode(
            episode_id=episode_id,
            asset="TEST",
            event_time=self.t0,
            w0_boundary=self.t0,
            evidence=[
                Evidence(
                    "expectation_revision",
                    feature_value,
                    Provenance("pre_event", self.t0, status=EvidenceStatus.OBSERVED),
                ),
            ],
            outcome=Outcome(
                episode_id=episode_id,
                realized=realized,
                target="next_session_return",
                observed_at=self.post,
            ),
        )

    def static_classifier(self, kind=ErrorKind.STRUCTURAL, structural_features=("event_relation",)):
        def _classify(episode, residual, model, history):
            return DoorDiagnosis(kind=kind, structural_features=structural_features)
        return _classify

    def static_accommodation_policy(self, accommodation_type="structural", improvement=0.0):
        """Failed accommodation policy — never improves the error."""
        def _policy(model, episodes, diagnosed, history):
            records = []
            for error in diagnosed:
                records.append(
                    AccommodationRecord(
                        generation_id=model.model_id,
                        signature=error.signature,
                        accommodation_type=accommodation_type,
                        prospective_improvement=improvement,
                        status="failed" if improvement <= 0 else "successful",
                    )
                )
            return records
        return _policy

    def plateau_survivor(self):
        """A survivor constructor that returns the same model each cycle.

        Used with a scripted evaluator to produce deterministic adequacy
        trajectories for the diagnostic layer.
        """
        def _survive(model, episodes, diagnosed, accommodations, adequacy, history):
            next_id = f"M{int(model.model_id[1:]) + 1}"
            return LinearModel(
                model_id=next_id,
                features=model.features,
                intercept=model.intercept,
                coefficients=model.coefficients,
            )
        return _survive

    def scripted_evaluator(self, scores):
        """An evaluator that returns pre-defined adequacy scores by cycle index.

        This produces a deterministic diminishing-returns pattern that
        the diagnostic layer can detect as a persistent blind spot.
        """
        def _evaluator(model, episodes, diagnosed, accommodations, history):
            idx = len(history.generations)
            if idx < len(scores):
                return scores[idx]
            return scores[-1]
        return _evaluator

    def improving_survivor(self):
        """A survivor that shifts the coefficient to reduce the residual."""
        def _survive(model, episodes, diagnosed, accommodations, adequacy, history):
            next_id = f"M{int(model.model_id[1:]) + 1}"
            # Nudge the coefficient slightly.
            new_coefs = tuple(c * 0.99 for c in model.coefficients)
            return LinearModel(
                model_id=next_id,
                features=model.features,
                intercept=model.intercept,
                coefficients=new_coefs,
            )
        return _survive

    def make_orchestrator(self, history=None, **overrides):
        defaults = dict(
            history=history or ModelHistory(),
            classifier=self.static_classifier(),
            accommodation_policy=self.static_accommodation_policy(),
            evaluator=self.scripted_evaluator([0.50, 0.70, 0.80, 0.84, 0.85]),
            survivor_constructor=self.plateau_survivor(),
        )
        defaults.update(overrides)
        return RevisionOrchestrator(**defaults)

    def dominant_policy(self, signature):
        """A dominance policy that marks the given signature as dominant."""
        def _policy(history):
            return [signature]
        return _policy

    def constraint_provider(self, signature, present=True, constraint_id="IC-LOOP"):
        """A constraint provider that returns a fixed constraint for a signature."""
        def _provider(trajectories, assessments, history):
            return {
                signature: IndependentConstraint(
                    present=present, constraint_id=constraint_id
                )
            }
        return _provider


class TestRevisionLoopBasics(unittest.TestCase, _LoopFixture):
    def setUp(self):
        _LoopFixture.__init__(self)

    def test_loop_runs_multiple_cycles_with_lineage(self):
        history = ModelHistory()
        orch = self.make_orchestrator(history=history)
        episodes = [self.episode("E0", 1.0, -0.02)]
        loop = RevisionLoop(
            orchestrator=orch,
            episode_provider=fixed_episode_provider(episodes),
            max_cycles=3,
            min_cycles_before_diagnostics=10,  # don't trigger diagnostics
        )

        result = loop.run(LinearModel("M0", ("expectation_revision",), 0.0, (0.01,)))

        self.assertEqual(result.status, RevisionLoopStatus.MAX_CYCLES_REACHED)
        self.assertEqual(len(result.cycles), 3)
        # Lineage is contiguous.
        self.assertEqual(history.generations[0].model_id, "M0")
        self.assertEqual(history.generations[1].model_id, "M1")
        self.assertEqual(history.generations[1].parent_model_id, "M0")
        self.assertEqual(history.generations[2].model_id, "M2")
        self.assertEqual(history.generations[2].parent_model_id, "M1")

    def test_loop_stops_on_no_episodes(self):
        orch = self.make_orchestrator()
        loop = RevisionLoop(
            orchestrator=orch,
            episode_provider=fixed_episode_provider([]),
            max_cycles=5,
        )

        result = loop.run(LinearModel("M0", ("expectation_revision",), 0.0, (0.01,)))

        self.assertEqual(result.status, RevisionLoopStatus.NO_EPISODES)
        self.assertEqual(len(result.cycles), 0)

    def test_loop_stops_on_max_cycles(self):
        history = ModelHistory()
        orch = self.make_orchestrator(history=history)
        episodes = [self.episode("E0", 1.0, -0.02)]
        loop = RevisionLoop(
            orchestrator=orch,
            episode_provider=fixed_episode_provider(episodes),
            max_cycles=2,
            min_cycles_before_diagnostics=10,
        )

        result = loop.run(LinearModel("M0", ("expectation_revision",), 0.0, (0.01,)))

        self.assertEqual(result.status, RevisionLoopStatus.MAX_CYCLES_REACHED)
        self.assertEqual(len(result.cycles), 2)


class TestRevisionLoopOORAndZD(unittest.TestCase, _LoopFixture):
    def setUp(self):
        _LoopFixture.__init__(self)

    def test_full_autonomous_chain_generates_zd_candidate(self):
        """The loop detects a persistent blind spot, opens the OOR gate,
        and generates a Z_D candidate."""
        history = ModelHistory()
        orch = self.make_orchestrator(history=history)
        episodes = [self.episode("E0", 1.0, -0.02)]

        loop = RevisionLoop(
            orchestrator=orch,
            episode_provider=fixed_episode_provider(episodes),
            dominance_policy=self.dominant_policy(self.signature),
            constraint_provider=self.constraint_provider(self.signature, present=True),
            max_cycles=10,
            min_cycles_before_diagnostics=2,
            plateau_window=5,  # don't trigger plateau before blind spot
        )

        result = loop.run(LinearModel("M0", ("expectation_revision",), 0.0, (0.01,)))

        self.assertEqual(result.status, RevisionLoopStatus.ZD_CANDIDATE_GENERATED)
        self.assertGreaterEqual(len(result.cycles), 2)
        self.assertGreaterEqual(len(result.oor_results), 1)
        self.assertGreaterEqual(len(result.zd_results), 1)
        # The Z_D candidate was actually generated.
        zd = result.zd_results[0]
        self.assertIsNotNone(zd.candidate)
        self.assertEqual(zd.candidate.candidate_id, "Z_D")
        self.assertEqual(zd.candidate.source_constraint_id, "IC-LOOP")

    def test_no_independent_constraint_stops_at_oor_required(self):
        """A persistent blind spot without a constraint stops the loop."""
        history = ModelHistory()
        orch = self.make_orchestrator(history=history)
        episodes = [self.episode("E0", 1.0, -0.02)]

        loop = RevisionLoop(
            orchestrator=orch,
            episode_provider=fixed_episode_provider(episodes),
            dominance_policy=self.dominant_policy(self.signature),
            constraint_provider=self.constraint_provider(self.signature, present=False),
            max_cycles=10,
            min_cycles_before_diagnostics=2,
            plateau_window=5,
        )

        result = loop.run(LinearModel("M0", ("expectation_revision",), 0.0, (0.01,)))

        self.assertEqual(result.status, RevisionLoopStatus.OOR_CONSTRAINT_REQUIRED)
        self.assertGreaterEqual(len(result.oor_results), 1)
        # No Z_D candidate was generated.
        self.assertEqual(len(result.zd_results), 0)

    def test_no_dominance_policy_does_not_trigger_blind_spot(self):
        """Without a dominance policy, no persistent blind spot emerges."""
        history = ModelHistory()
        orch = self.make_orchestrator(history=history)
        episodes = [self.episode("E0", 1.0, -0.02)]

        loop = RevisionLoop(
            orchestrator=orch,
            episode_provider=fixed_episode_provider(episodes),
            dominance_policy=no_dominant_families,
            constraint_provider=no_independent_constraints,
            max_cycles=4,
            min_cycles_before_diagnostics=2,
            plateau_window=5,
        )

        result = loop.run(LinearModel("M0", ("expectation_revision",), 0.0, (0.01,)))

        # Without dominance, no blind spot → either plateau or max cycles.
        self.assertIn(
            result.status,
            (RevisionLoopStatus.ADEQUACY_PLATEAU, RevisionLoopStatus.MAX_CYCLES_REACHED),
        )
        self.assertEqual(len(result.zd_results), 0)


class TestRevisionLoopPlateau(unittest.TestCase, _LoopFixture):
    def setUp(self):
        _LoopFixture.__init__(self)

    def test_plateau_stops_loop_without_blind_spot(self):
        """When adequacy improvement plateaus without a blind spot, the loop stops."""
        history = ModelHistory()
        orch = self.make_orchestrator(history=history)
        episodes = [self.episode("E0", 1.0, -0.02)]

        loop = RevisionLoop(
            orchestrator=orch,
            episode_provider=fixed_episode_provider(episodes),
            dominance_policy=no_dominant_families,
            constraint_provider=no_independent_constraints,
            max_cycles=10,
            min_cycles_before_diagnostics=2,
            plateau_window=2,
            min_adequacy_improvement=0.0,
        )

        result = loop.run(LinearModel("M0", ("expectation_revision",), 0.0, (0.01,)))

        # The plateau survivor doesn't change the model, so adequacy
        # improvement should be zero after cycle 2 (same model → same
        # predictions → same residuals → same adequacy).
        self.assertIn(
            result.status,
            (RevisionLoopStatus.ADEQUACY_PLATEAU, RevisionLoopStatus.MAX_CYCLES_REACHED),
        )


class TestEpisodeProviders(unittest.TestCase):
    def test_fixed_provider_returns_same_episodes(self):
        from datetime import datetime, timezone

        t0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
        post = datetime(2026, 1, 2, tzinfo=timezone.utc)
        ep = EarningsEpisode(
            episode_id="E0",
            asset="TEST",
            event_time=t0,
            w0_boundary=t0,
            evidence=[],
            outcome=Outcome("E0", -0.02, "ret", post),
        )

        provider = fixed_episode_provider([ep])
        history = ModelHistory()

        result0 = provider(0, None, history)
        result1 = provider(1, None, history)

        self.assertEqual(len(result0), 1)
        self.assertEqual(len(result1), 1)
        self.assertEqual(result0[0].episode_id, "E0")
        self.assertEqual(result1[0].episode_id, "E0")

    def test_batched_provider_cycles_through_batches(self):
        from datetime import datetime, timezone

        t0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
        post = datetime(2026, 1, 2, tzinfo=timezone.utc)
        ep0 = EarningsEpisode("E0", "TEST", t0, t0, [], Outcome("E0", -0.01, "ret", post))
        ep1 = EarningsEpisode("E1", "TEST", t0, t0, [], Outcome("E1", -0.02, "ret", post))

        provider = batched_episode_provider([[ep0], [ep1]])
        history = ModelHistory()

        self.assertEqual(provider(0, None, history)[0].episode_id, "E0")
        self.assertEqual(provider(1, None, history)[0].episode_id, "E1")
        # Last batch is reused.
        self.assertEqual(provider(2, None, history)[0].episode_id, "E1")


class TestLoopGuardrails(unittest.TestCase):
    def test_loop_imports_oor_and_zd_generation(self):
        """The loop driver is the module that bridges the components."""
        import cvr30.loop as loop_module

        # The loop should import OOR and Z_D generation.
        self.assertTrue(hasattr(loop_module, "review_history_for_oor"))
        self.assertTrue(hasattr(loop_module, "generate_zd_candidate"))

    def test_orchestrator_still_does_not_import_oor(self):
        """The orchestrator remains decoupled from OOR and Z_D."""
        import cvr30.orchestrator as orch_module
        import importlib

        spec = importlib.util.find_spec("cvr30.orchestrator")
        with open(spec.origin) as f:
            source = f.read()

        import_lines = [
            line.strip() for line in source.splitlines()
            if line.strip().startswith("from .oor")
            or line.strip().startswith("from .zd")
            or line.strip().startswith("from .gate")
            or line.strip().startswith("from .pilot")
            or line.strip().startswith("from .loop")
        ]
        self.assertEqual(import_lines, [])

    def test_result_history_is_accessible(self):
        """The loop result should expose the model history."""
        from cvr30.loop import RevisionLoop, fixed_episode_provider

        history = ModelHistory()
        orch = self.make_orchestrator if hasattr(self, 'make_orchestrator') else None

        # Use a minimal setup.
        t0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
        post = datetime(2026, 1, 2, tzinfo=timezone.utc)
        ep = EarningsEpisode(
            episode_id="E0", asset="TEST", event_time=t0, w0_boundary=t0,
            evidence=[Evidence("x", 1.0, Provenance("pre", t0, status=EvidenceStatus.OBSERVED))],
            outcome=Outcome("E0", -0.02, "ret", post),
        )

        def classifier(episode, residual, model, history):
            return DoorDiagnosis(kind=ErrorKind.STRUCTURAL, structural_features=("event_relation",))

        def accom(model, episodes, diagnosed, history):
            return []

        def survive(model, episodes, diagnosed, accommodations, adequacy, history):
            next_id = f"M{int(model.model_id[1:]) + 1}"
            return LinearModel(next_id, model.features, model.intercept, model.coefficients)

        def evaluator(model, episodes, diagnosed, accommodations, history):
            return 0.50

        orch = RevisionOrchestrator(
            history=history,
            classifier=classifier,
            accommodation_policy=accom,
            evaluator=evaluator,
            survivor_constructor=survive,
        )

        loop = RevisionLoop(
            orchestrator=orch,
            episode_provider=fixed_episode_provider([ep]),
            max_cycles=2,
            min_cycles_before_diagnostics=10,
        )

        result = loop.run(LinearModel("M0", ("x",), 0.0, (0.01,)))
        self.assertIs(result.history, history)

    def test_invalid_check_every_raises(self):
        from cvr30.loop import RevisionLoop

        with self.assertRaises(ValueError):
            RevisionLoop(
                orchestrator=RevisionOrchestrator(
                    history=ModelHistory(),
                    classifier=lambda e, r, m, h: DoorDiagnosis(),
                    accommodation_policy=lambda m, e, d, h: [],
                    evaluator=lambda m, e, d, a, h: 0.5,
                    survivor_constructor=lambda m, e, d, a, ade, h: m,
                ),
                episode_provider=fixed_episode_provider([]),
                check_every=0,
            )

    def test_invalid_plateau_window_raises(self):
        from cvr30.loop import RevisionLoop

        with self.assertRaises(ValueError):
            RevisionLoop(
                orchestrator=RevisionOrchestrator(
                    history=ModelHistory(),
                    classifier=lambda e, r, m, h: DoorDiagnosis(),
                    accommodation_policy=lambda m, e, d, h: [],
                    evaluator=lambda m, e, d, a, h: 0.5,
                    survivor_constructor=lambda m, e, d, a, ade, h: m,
                ),
                episode_provider=fixed_episode_provider([]),
                plateau_window=0,
            )


if __name__ == "__main__":
    unittest.main()
