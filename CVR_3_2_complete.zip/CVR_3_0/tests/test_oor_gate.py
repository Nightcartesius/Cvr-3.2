import unittest

from cvr30.diagnostic import (
    AccommodationRecord,
    DiagnosticAssessment,
    DiagnosticStatus,
    ErrorSignature,
    ErrorTrajectory,
)
from cvr30.oor import (
    OORGateResult,
    OORGateStatus,
    review_trajectory_for_oor,
    review_history_for_oor,
)
from cvr30.types import ErrorKind


def _trajectory(occurrences, accommodations=(), adequacy_history=(), improvement_history=()):
    """Build a minimal ErrorTrajectory for testing."""
    sig = ErrorSignature(
        kind=ErrorKind.STRUCTURAL,
        target="y",
        structural_features=("gravity_rule",),
        direction=1,
    )
    return ErrorTrajectory(
        signature=sig,
        occurrences=tuple(occurrences),
        accommodation_history=tuple(accommodations),
        adequacy_history=tuple(adequacy_history),
        improvement_history=tuple(improvement_history),
    )


def _persistent_blind_spot_assessment():
    return DiagnosticAssessment(
        status=DiagnosticStatus.PERSISTENT_BLIND_SPOT,
        persistent=True,
        diminishing_returns=True,
        limiting_residual=True,
        structural_non_accommodation=True,
        accommodation_attempts=1,
        successful_accommodations=0,
        reasons=("Persistent blind spot.",),
    )


def _recurrent_assessment():
    return DiagnosticAssessment(
        status=DiagnosticStatus.RECURRENT_ERROR,
        persistent=True,
        diminishing_returns=False,
        limiting_residual=False,
        structural_non_accommodation=False,
        accommodation_attempts=0,
        successful_accommodations=0,
        reasons=("Recurrent but not yet limiting.",),
    )


def _corrigible_assessment():
    return DiagnosticAssessment(
        status=DiagnosticStatus.CORRIGIBLE_ERROR,
        persistent=True,
        diminishing_returns=False,
        limiting_residual=True,
        structural_non_accommodation=False,
        accommodation_attempts=1,
        successful_accommodations=1,
        reasons=("Corrigible.",),
    )


class TestOORGateSingleTrajectory(unittest.TestCase):
    def test_candidate_oor_with_independent_constraint(self):
        trajectory = _trajectory(
            occurrences=[("M0", 0.8), ("M1", 0.85), ("M2", 0.83)],
            adequacy_history=(0.50, 0.70, 0.80, 0.84),
            improvement_history=(0.20, 0.10, 0.04),
        )
        assessment = _persistent_blind_spot_assessment()

        result = review_trajectory_for_oor(
            trajectory,
            assessment,
            independent_constraint=True,
            constraint_id="IC-001",
        )

        self.assertEqual(result.status, OORGateStatus.CANDIDATE_OOR)
        self.assertTrue(result.candidate_oor)
        self.assertTrue(result.eligible_for_zd_generation)
        self.assertEqual(result.constraint_id, "IC-001")
        self.assertAlmostEqual(result.latest_residual, 0.83)
        self.assertEqual(result.persistence_score, 1.0)
        self.assertTrue(result.independent_constraint)

    def test_persistent_blind_spot_without_independent_constraint(self):
        trajectory = _trajectory(
            occurrences=[("M0", 0.8), ("M1", 0.85), ("M2", 0.83)],
        )
        assessment = _persistent_blind_spot_assessment()

        result = review_trajectory_for_oor(
            trajectory,
            assessment,
            independent_constraint=False,
        )

        self.assertEqual(result.status, OORGateStatus.INDEPENDENT_CONSTRAINT_REQUIRED)
        self.assertFalse(result.candidate_oor)
        self.assertFalse(result.eligible_for_zd_generation)
        self.assertFalse(result.independent_constraint)
        self.assertIn("independent constraint", result.reasons[0].lower())

    def test_recurrent_error_is_not_reviewable(self):
        trajectory = _trajectory(
            occurrences=[("M0", 0.8), ("M1", 0.7)],
        )
        assessment = _recurrent_assessment()

        result = review_trajectory_for_oor(
            trajectory,
            assessment,
            independent_constraint=True,
        )

        self.assertEqual(result.status, OORGateStatus.NOT_REVIEWABLE)
        self.assertFalse(result.candidate_oor)
        self.assertFalse(result.eligible_for_zd_generation)

    def test_corrigible_error_is_not_reviewable(self):
        trajectory = _trajectory(
            occurrences=[("M0", 0.8), ("M1", 0.2)],
        )
        assessment = _corrigible_assessment()

        result = review_trajectory_for_oor(
            trajectory,
            assessment,
            independent_constraint=True,
        )

        self.assertEqual(result.status, OORGateStatus.NOT_REVIEWABLE)
        self.assertFalse(result.candidate_oor)

    def test_zero_residual_is_not_oor(self):
        """A persistent blind spot whose residual was driven to zero."""
        trajectory = _trajectory(
            occurrences=[("M0", 0.8), ("M1", 0.0)],
        )
        assessment = _persistent_blind_spot_assessment()

        result = review_trajectory_for_oor(
            trajectory,
            assessment,
            independent_constraint=True,
            residual_tolerance=0.001,
        )

        self.assertEqual(result.status, OORGateStatus.NOT_OOR)
        self.assertFalse(result.candidate_oor)
        self.assertFalse(result.eligible_for_zd_generation)

    def test_low_persistence_is_not_oor(self):
        """A persistent blind spot with only one occurrence."""
        trajectory = _trajectory(
            occurrences=[("M0", 0.8)],
        )
        assessment = _persistent_blind_spot_assessment()

        result = review_trajectory_for_oor(
            trajectory,
            assessment,
            independent_constraint=True,
            min_occurrences_for_full_persistence=4,
            min_persistence=0.5,
        )

        # persistence_score = 1/4 = 0.25 < 0.5
        self.assertEqual(result.status, OORGateStatus.NOT_OOR)
        self.assertFalse(result.candidate_oor)
        self.assertLess(result.persistence_score, 0.5)

    def test_candidate_oor_does_not_generate_zd(self):
        """The gate exposes eligibility but does not produce a Z_D object."""
        trajectory = _trajectory(
            occurrences=[("M0", 0.8), ("M1", 0.85), ("M2", 0.83)],
        )
        assessment = _persistent_blind_spot_assessment()

        result = review_trajectory_for_oor(
            trajectory,
            assessment,
            independent_constraint=True,
        )

        self.assertTrue(result.eligible_for_zd_generation)
        # The result has no Z_D field — only the eligibility flag.
        self.assertFalse(hasattr(result, "zd") or hasattr(result, "z_d"))


class TestOORGateHistoryWrapper(unittest.TestCase):
    def test_review_history_reviews_all_trajectories(self):
        sig_a = ErrorSignature(
            kind=ErrorKind.STRUCTURAL,
            target="y",
            structural_features=("gravity_rule",),
            direction=1,
        )
        sig_b = ErrorSignature(
            kind=ErrorKind.PARAMETER,
            target="z",
            direction=-1,
        )

        traj_a = ErrorTrajectory(
            signature=sig_a,
            occurrences=[("M0", 0.8), ("M1", 0.85), ("M2", 0.83)],
            accommodation_history=(),
            adequacy_history=(0.50, 0.70, 0.80, 0.84),
            improvement_history=(0.20, 0.10, 0.04),
        )
        traj_b = ErrorTrajectory(
            signature=sig_b,
            occurrences=[("M0", 0.1), ("M1", 0.05)],
            accommodation_history=(),
            adequacy_history=(0.50, 0.70),
            improvement_history=(0.20,),
        )

        assessments = {
            sig_a: _persistent_blind_spot_assessment(),
            sig_b: _recurrent_assessment(),
        }

        results = review_history_for_oor(
            [traj_a, traj_b],
            assessments,
            independent_constraints={sig_a: True, sig_b: True},
            constraint_ids={sig_a: "IC-A"},
        )

        self.assertEqual(len(results), 2)
        # sig_a should be candidate OOR.
        oor_a = [r for r in results if r.signature == sig_a][0]
        self.assertEqual(oor_a.status, OORGateStatus.CANDIDATE_OOR)
        self.assertEqual(oor_a.constraint_id, "IC-A")
        # sig_b should be not reviewable (recurrent, not blind spot).
        oor_b = [r for r in results if r.signature == sig_b][0]
        self.assertEqual(oor_b.status, OORGateStatus.NOT_REVIEWABLE)

    def test_missing_constraint_defaults_to_false(self):
        """A trajectory with no constraint entry is treated as no constraint."""
        sig = ErrorSignature(
            kind=ErrorKind.STRUCTURAL,
            target="y",
            structural_features=("gravity_rule",),
            direction=1,
        )
        traj = ErrorTrajectory(
            signature=sig,
            occurrences=[("M0", 0.8), ("M1", 0.85), ("M2", 0.83)],
            accommodation_history=(),
            adequacy_history=(0.50, 0.70, 0.80, 0.84),
            improvement_history=(0.20, 0.10, 0.04),
        )
        assessments = {sig: _persistent_blind_spot_assessment()}

        results = review_history_for_oor(
            [traj],
            assessments,
            independent_constraints={},  # no constraint for this signature
        )

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].status, OORGateStatus.INDEPENDENT_CONSTRAINT_REQUIRED)


class TestEpisodeLevelOORBackwardCompat(unittest.TestCase):
    """The existing episode-level OOR functions must still work."""

    def test_episode_level_diagnose_still_works(self):
        from cvr30.oor import diagnose, is_candidate_oor, OORObservation

        diag = diagnose(
            0.01,
            -0.02,
            persistence=0.8,
            independent_constraint=True,
            classification=ErrorKind.STRUCTURAL,
        )
        self.assertEqual(diag.error, -0.03)
        self.assertEqual(diag.kind, ErrorKind.STRUCTURAL)

        obs = OORObservation(
            predicted=0.01,
            actual=-0.02,
            persistence=0.8,
            independent_constraint=True,
        )
        self.assertTrue(is_candidate_oor(obs, min_persistence=0.5))

        obs_no_constraint = OORObservation(
            predicted=0.01,
            actual=-0.02,
            persistence=0.8,
            independent_constraint=False,
        )
        self.assertFalse(is_candidate_oor(obs_no_constraint))


class TestOOREndToEndIntegration(unittest.TestCase):
    """Full diagnostic → OOR gate integration using real ModelHistory."""

    def test_history_assess_feeds_oor_gate(self):
        from cvr30.diagnostic import ModelHistory, ModelGeneration

        sig = ErrorSignature(
            kind=ErrorKind.STRUCTURAL,
            target="y",
            structural_features=("gravity_rule",),
            direction=1,
        )

        failed_accommodation = AccommodationRecord(
            generation_id="M2",
            signature=sig,
            accommodation_type="structural",
            prospective_improvement=0.0,
            status="failed",
        )

        # Build the diminishing-returns + persistent blind spot pattern
        # that the diagnostic tests already use.
        generations = [
            ModelGeneration("M0", None, 0.50, ((sig, 1.0),)),
            ModelGeneration("M1", "M0", 0.70, ((sig, 0.9),)),
            ModelGeneration("M2", "M1", 0.80, ((sig, 0.85),), (failed_accommodation,)),
            ModelGeneration("M3", "M2", 0.84, ((sig, 0.83),)),
        ]

        history = ModelHistory()
        for g in generations:
            history.append(g)

        # Real diagnostic assessment — dominant=True is required for
        # PERSISTENT_BLIND_SPOT to emerge.
        assessments = history.assess(dominant_families=[sig])
        self.assertEqual(len(assessments), 1)
        assessment = assessments[sig]
        self.assertEqual(assessment.status, DiagnosticStatus.PERSISTENT_BLIND_SPOT)
        self.assertTrue(assessment.eligible_for_oor_review)

        # Feed the real assessment through the OOR gate.
        trajectories = history.trajectories()
        results = review_history_for_oor(
            trajectories,
            assessments,
            independent_constraints={sig: True},
            constraint_ids={sig: "IC-END-TO-END"},
        )

        self.assertEqual(len(results), 1)
        result = results[0]
        self.assertEqual(result.status, OORGateStatus.CANDIDATE_OOR)
        self.assertTrue(result.candidate_oor)
        self.assertTrue(result.eligible_for_zd_generation)
        self.assertEqual(result.constraint_id, "IC-END-TO-END")
        self.assertAlmostEqual(result.latest_residual, 0.83)

    def test_end_to_end_without_independent_constraint(self):
        """Same history, but no independent constraint → not OOR."""
        from cvr30.diagnostic import ModelHistory, ModelGeneration

        sig = ErrorSignature(
            kind=ErrorKind.STRUCTURAL,
            target="y",
            structural_features=("gravity_rule",),
            direction=1,
        )
        failed_accommodation = AccommodationRecord(
            generation_id="M2",
            signature=sig,
            accommodation_type="structural",
            prospective_improvement=0.0,
            status="failed",
        )
        generations = [
            ModelGeneration("M0", None, 0.50, ((sig, 1.0),)),
            ModelGeneration("M1", "M0", 0.70, ((sig, 0.9),)),
            ModelGeneration("M2", "M1", 0.80, ((sig, 0.85),), (failed_accommodation,)),
            ModelGeneration("M3", "M2", 0.84, ((sig, 0.83),)),
        ]

        history = ModelHistory()
        for g in generations:
            history.append(g)

        assessments = history.assess(dominant_families=[sig])
        results = review_history_for_oor(
            history.trajectories(),
            assessments,
            independent_constraints={},  # no constraint
        )

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].status, OORGateStatus.INDEPENDENT_CONSTRAINT_REQUIRED)
        self.assertFalse(results[0].eligible_for_zd_generation)


if __name__ == "__main__":
    unittest.main()
