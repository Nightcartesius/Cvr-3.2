import unittest
from dataclasses import dataclass
from datetime import datetime, timezone

from cvr30.diagnostic import (
    AccommodationRecord,
    ErrorSignature,
    ModelHistory,
)
from cvr30.episode import EarningsEpisode
from cvr30.models import LinearModel
from cvr30.orchestrator import (
    DiagnosedError,
    DoorDiagnosis,
    RevisionCycleResult,
    RevisionOrchestrator,
    inverse_rmse_adequacy,
)
from cvr30.types import ErrorKind, Evidence, Outcome, Prediction, Provenance, EvidenceStatus


class _OrchestratorFixture:
    """Shared test fixtures for the orchestrator tests."""

    def __init__(self):
        self.t0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
        self.post = datetime(2026, 1, 2, tzinfo=timezone.utc)

    def episode(self, episode_id, feature_value, realized, model_id="M0"):
        evidence = [
            Evidence(
                "expectation_revision",
                feature_value,
                Provenance("pre_event", self.t0, status=EvidenceStatus.OBSERVED),
            ),
        ]
        return EarningsEpisode(
            episode_id=episode_id,
            asset="TEST",
            event_time=self.t0,
            w0_boundary=self.t0,
            evidence=evidence,
            outcome=Outcome(
                episode_id=episode_id,
                realized=realized,
                target="next_session_return",
                observed_at=self.post,
            ),
        )

    def static_classifier(self, kind=ErrorKind.STRUCTURAL, structural_features=("event_relation",)):
        """A classifier that returns the same diagnosis for every episode."""

        def _classify(episode, residual, model, history):
            return DoorDiagnosis(
                kind=kind,
                structural_features=structural_features,
            )

        return _classify

    def static_accommodation_policy(self, accommodation_type="structural", improvement=0.15):
        """An accommodation policy that returns one record per diagnosed error."""

        def _policy(model, episodes, diagnosed, history):
            records = []
            for error in diagnosed:
                records.append(
                    AccommodationRecord(
                        generation_id=model.model_id,
                        signature=error.signature,
                        accommodation_type=accommodation_type,
                        prospective_improvement=improvement,
                        status="successful" if improvement > 0 else "failed",
                    )
                )
            return records

        return _policy

    def linear_survivor(self, next_model_id_template="M{n}"):
        """A survivor constructor that returns a slightly adjusted LinearModel."""

        def _survive(model, episodes, diagnosed, accommodations, adequacy, history):
            next_id = next_model_id_template.format(n=int(model.model_id[1:]) + 1)
            # Shift the coefficient slightly toward reducing the residual.
            return LinearModel(
                model_id=next_id,
                features=model.features,
                intercept=model.intercept + 0.001,
                coefficients=model.coefficients,
            )

        return _survive

    def make_orchestrator(self, history=None, **overrides):
        defaults = dict(
            history=history or ModelHistory(),
            classifier=self.static_classifier(),
            accommodation_policy=self.static_accommodation_policy(),
            evaluator=inverse_rmse_adequacy,
            survivor_constructor=self.linear_survivor(),
        )
        defaults.update(overrides)
        return RevisionOrchestrator(**defaults)


class TestOrchestratorSingleCycle(unittest.TestCase, _OrchestratorFixture):
    def setUp(self):
        _OrchestratorFixture.__init__(self)

    def test_single_cycle_records_generation_and_returns_next_model(self):
        history = ModelHistory()
        orch = self.make_orchestrator(history=history)
        model = LinearModel("M0", ("expectation_revision",), 0.0, (0.01,))
        episodes = [self.episode("E0", 1.0, -0.02)]

        result = orch.run_cycle(model, episodes)

        # The generation is recorded in history.
        self.assertEqual(len(history.generations), 1)
        self.assertEqual(history.generations[0].model_id, "M0")
        self.assertIsNone(history.generations[0].parent_model_id)

        # The cycle result carries the boundary outputs.
        self.assertIsInstance(result, RevisionCycleResult)
        self.assertEqual(result.current_model_id, "M0")
        self.assertEqual(result.next_model.model_id, "M1")
        self.assertEqual(result.generation.model_id, "M0")
        self.assertEqual(result.adequacy_score, history.generations[0].adequacy_score)

        # Predictions were produced by M0.
        self.assertEqual(result.episodes[0].prediction.model_id, "M0")
        self.assertEqual(result.episodes[0].prediction.target, "next_session_return")

        # Diagnosed errors carry structural signatures.
        self.assertEqual(len(result.diagnosed_errors), 1)
        self.assertEqual(result.diagnosed_errors[0].diagnosis.kind, ErrorKind.STRUCTURAL)
        self.assertEqual(
            result.diagnosed_errors[0].signature.structural_features, ("event_relation",)
        )

        # Accommodations are attached to the generation.
        self.assertEqual(len(result.accommodations), 1)
        self.assertEqual(history.generations[0].accommodations[0].accommodation_type, "structural")

        # Revision metadata is preserved.
        self.assertEqual(history.generations[0].metadata["next_model_id"], "M1")

    def test_adequacy_score_is_caller_supplied(self):
        """The evaluator is injected, not baked in."""
        history = ModelHistory()

        def custom_evaluator(model, episodes, diagnosed, accommodations, history):
            return 0.42

        orch = self.make_orchestrator(history=history, evaluator=custom_evaluator)
        model = LinearModel("M0", ("expectation_revision",), 0.0, (0.01,))
        episodes = [self.episode("E0", 1.0, -0.02)]

        result = orch.run_cycle(model, episodes)

        self.assertEqual(result.adequacy_score, 0.42)
        self.assertEqual(history.generations[0].adequacy_score, 0.42)


class TestOrchestratorTwoCycles(unittest.TestCase, _OrchestratorFixture):
    def setUp(self):
        _OrchestratorFixture.__init__(self)

    def test_two_cycles_link_parent_and_build_trajectory(self):
        history = ModelHistory()
        orch = self.make_orchestrator(history=history)
        m0 = LinearModel("M0", ("expectation_revision",), 0.0, (0.01,))
        e0 = self.episode("E0", 1.0, -0.02)

        cycle1 = orch.run_cycle(m0, [e0])
        m1 = cycle1.next_model
        e1 = self.episode("E1", 1.0, -0.015, model_id="M1")

        cycle2 = orch.run_cycle(m1, [e1])

        # Lineage is contiguous.
        self.assertEqual(history.generations[0].model_id, "M0")
        self.assertEqual(history.generations[1].model_id, "M1")
        self.assertEqual(history.generations[1].parent_model_id, "M0")

        # The second cycle's next model is M2.
        self.assertEqual(cycle2.next_model.model_id, "M2")

        # Trajectories work without special handling.
        trajectories = history.trajectories()
        self.assertGreaterEqual(len(trajectories), 1)
        # The structural error family persists across both generations.
        persistent = [t for t in trajectories if t.persistent]
        self.assertTrue(any(t.signature.kind == ErrorKind.STRUCTURAL for t in persistent))

        # Adequacy history is contiguous.
        self.assertEqual(len(history.adequacy_history), 2)
        self.assertEqual(len(history.improvement_history), 1)


class TestOrchestratorBoundaries(unittest.TestCase, _OrchestratorFixture):
    def setUp(self):
        _OrchestratorFixture.__init__(self)

    def test_completed_episode_required(self):
        orch = self.make_orchestrator()
        model = LinearModel("M0", ("expectation_revision",), 0.0, (0.01,))
        # Episode with no outcome.
        episode = EarningsEpisode(
            episode_id="E0",
            asset="TEST",
            event_time=self.t0,
            w0_boundary=self.t0,
            evidence=[
                Evidence(
                    "expectation_revision",
                    1.0,
                    Provenance("pre", self.t0, status=EvidenceStatus.OBSERVED),
                ),
            ],
        )
        with self.assertRaises(ValueError):
            orch.run_cycle(model, [episode])

    def test_empty_episodes_rejected(self):
        orch = self.make_orchestrator()
        model = LinearModel("M0", ("expectation_revision",), 0.0, (0.01,))
        with self.assertRaises(ValueError):
            orch.run_cycle(model, [])

    def test_w0_leakage_enforced_by_default(self):
        history = ModelHistory()
        orch = self.make_orchestrator(history=history)
        model = LinearModel("M0", ("expectation_revision",), 0.0, (0.01,))

        # Post-boundary evidence should be rejected.
        post_evidence = Evidence(
            "future_signal",
            0.5,
            Provenance("post_event", self.post, status=EvidenceStatus.OBSERVED),
        )
        episode = EarningsEpisode(
            episode_id="E0",
            asset="TEST",
            event_time=self.t0,
            w0_boundary=self.t0,
            evidence=[post_evidence],
            outcome=Outcome("E0", -0.02, "next_session_return", self.post),
        )
        with self.assertRaises(ValueError):
            orch.run_cycle(model, [episode])

    def test_w0_leakage_can_be_disabled(self):
        history = ModelHistory()
        orch = self.make_orchestrator(
            history=history, enforce_no_future_leakage=False
        )
        model = LinearModel("M0", ("expectation_revision",), 0.0, (0.01,))

        post_evidence = Evidence(
            "future_signal",
            0.5,
            Provenance("post_event", self.post, status=EvidenceStatus.OBSERVED),
        )
        episode = EarningsEpisode(
            episode_id="E0",
            asset="TEST",
            event_time=self.t0,
            w0_boundary=self.t0,
            evidence=[post_evidence],
            outcome=Outcome("E0", -0.02, "next_session_return", self.post),
        )
        # Should not raise when enforcement is disabled.
        result = orch.run_cycle(model, [episode])
        self.assertEqual(len(result.diagnosed_errors), 1)

    def test_orchestrator_does_not_import_oor_or_gate(self):
        """The orchestrator must not pull in OOR, gate, or pilot."""
        import cvr30.orchestrator as orch_module

        with open(orch_module.__file__) as f:
            source = f.read()
        self.assertNotIn("from .oor import", source)
        self.assertNotIn("from .gate import", source)
        self.assertNotIn("from .pilot import", source)
        self.assertNotIn("import cvr30.oor", source)
        self.assertNotIn("import cvr30.gate", source)
        self.assertNotIn("import cvr30.pilot", source)


class TestOrchestratorAccommodationHistory(unittest.TestCase, _OrchestratorFixture):
    def setUp(self):
        _OrchestratorFixture.__init__(self)

    def test_accommodation_records_flow_into_trajectory(self):
        history = ModelHistory()
        orch = self.make_orchestrator(history=history)
        m0 = LinearModel("M0", ("expectation_revision",), 0.0, (0.01,))
        e0 = self.episode("E0", 1.0, -0.02)

        orch.run_cycle(m0, [e0])

        trajectories = history.trajectories()
        # At least one trajectory should have an accommodation record.
        self.assertTrue(
            any(len(t.accommodation_history) >= 1 for t in trajectories)
        )
        # The accommodation should be marked as improved.
        for t in trajectories:
            for a in t.accommodation_history:
                self.assertTrue(a.improved)


if __name__ == "__main__":
    unittest.main()
