import unittest

from cvr30.diagnostic import (
    AccommodationRecord,
    DiagnosticAssessment,
    DiagnosticStatus,
    ErrorSignature,
    ErrorTrajectory,
    ModelGeneration,
    ModelHistory,
)
from cvr30.oor import (
    OORGateResult,
    OORGateStatus,
    review_trajectory_for_oor,
    review_history_for_oor,
)
from cvr30.types import ErrorKind
from cvr30.zd_generation import (
    ZDCandidateSpec,
    ZDGenerationResult,
    ZDMeasurementRequirement,
    ZDProposalStatus,
    ZDProposalStrategy,
    generate_zd_candidate,
    generate_zd_candidate_with_strategy,
    pilot_candidate_id,
)


def _candidate_oor_result() -> OORGateResult:
    """An OORGateResult that has opened the gate (candidate OOR)."""
    sig = ErrorSignature(
        kind=ErrorKind.STRUCTURAL,
        target="next_session_return",
        structural_features=("event_relation",),
        direction=-1,
    )
    return OORGateResult(
        signature=sig,
        status=OORGateStatus.CANDIDATE_OOR,
        candidate_oor=True,
        persistence_score=1.0,
        latest_residual=0.83,
        independent_constraint=True,
        constraint_id="IC-001",
        reasons=("Candidate OOR.",),
    )


def _not_eligible_oor_result() -> OORGateResult:
    """An OORGateResult that has not opened the gate."""
    sig = ErrorSignature(
        kind=ErrorKind.STRUCTURAL,
        target="next_session_return",
        structural_features=("event_relation",),
        direction=-1,
    )
    return OORGateResult(
        signature=sig,
        status=OORGateStatus.NOT_REVIEWABLE,
        candidate_oor=False,
        persistence_score=0.0,
        latest_residual=None,
        independent_constraint=False,
        constraint_id="",
        reasons=("Not reviewable.",),
    )


class TestZDGenerationEligibility(unittest.TestCase):
    def test_candidate_oor_generates_proposed_candidate(self):
        oor = _candidate_oor_result()
        result = generate_zd_candidate(oor)

        self.assertEqual(result.status, ZDProposalStatus.PROPOSED)
        self.assertIsNotNone(result.candidate)
        self.assertEqual(result.candidate.candidate_id, "Z_D")
        self.assertEqual(
            result.candidate.label,
            "pre-event expectation revision / expectation-state revision",
        )

    def test_not_eligible_returns_no_candidate(self):
        oor = _not_eligible_oor_result()
        result = generate_zd_candidate(oor)

        self.assertEqual(result.status, ZDProposalStatus.NOT_ELIGIBLE)
        self.assertIsNone(result.candidate)
        self.assertTrue(
            any("not eligible" in r.lower() for r in result.reasons)
        )

    def test_independent_constraint_required_result_is_not_eligible(self):
        """A persistent blind spot without an independent constraint."""
        sig = ErrorSignature(
            kind=ErrorKind.STRUCTURAL,
            target="y",
            structural_features=("gravity_rule",),
            direction=1,
        )
        oor = OORGateResult(
            signature=sig,
            status=OORGateStatus.INDEPENDENT_CONSTRAINT_REQUIRED,
            candidate_oor=False,
            persistence_score=0.5,
            latest_residual=0.8,
            independent_constraint=False,
            constraint_id="",
        )
        result = generate_zd_candidate(oor)
        self.assertEqual(result.status, ZDProposalStatus.NOT_ELIGIBLE)


class TestZDCandidateSpec(unittest.TestCase):
    def test_candidate_preserves_source_signature(self):
        oor = _candidate_oor_result()
        result = generate_zd_candidate(oor)

        self.assertIsNotNone(result.candidate)
        self.assertEqual(
            result.candidate.source_signature, oor.signature
        )
        self.assertEqual(
            result.candidate.source_signature.kind, ErrorKind.STRUCTURAL
        )
        self.assertEqual(
            result.candidate.source_signature.target, "next_session_return"
        )

    def test_candidate_preserves_constraint_id(self):
        oor = _candidate_oor_result()
        result = generate_zd_candidate(oor)

        self.assertEqual(result.candidate.source_constraint_id, "IC-001")
        self.assertEqual(result.candidate.oor_constraint_id, "IC-001")

    def test_candidate_metadata_preserves_oor_context(self):
        oor = _candidate_oor_result()
        result = generate_zd_candidate(oor)

        meta = result.candidate.metadata
        self.assertEqual(meta["source_oor_status"], "candidate_oor")
        self.assertEqual(meta["source_constraint_id"], "IC-001")
        self.assertAlmostEqual(meta["latest_residual"], 0.83)
        self.assertEqual(meta["persistence_score"], 1.0)
        self.assertTrue(meta["independent_constraint"])


class TestZDMeasurementRequirements(unittest.TestCase):
    def test_default_measurements_require_point_in_time(self):
        oor = _candidate_oor_result()
        result = generate_zd_candidate(oor)

        measurements = result.candidate.required_measurements
        self.assertGreaterEqual(len(measurements), 3)

        # Pre-event expectation must be point-in-time.
        pre_event = [m for m in measurements if m.name == "pre_event_expectation"]
        self.assertEqual(len(pre_event), 1)
        self.assertTrue(pre_event[0].point_in_time_required)

    def test_default_measurements_include_w0_boundary(self):
        oor = _candidate_oor_result()
        result = generate_zd_candidate(oor)

        measurements = result.candidate.required_measurements
        w0 = [m for m in measurements if "w0" in m.name.lower() or "boundary" in m.name.lower()]
        self.assertGreaterEqual(len(w0), 1)
        self.assertTrue(w0[0].point_in_time_required)

    def test_realized_outcome_is_evaluation_only(self):
        oor = _candidate_oor_result()
        result = generate_zd_candidate(oor)

        measurements = result.candidate.required_measurements
        outcome = [m for m in measurements if "realized" in m.name.lower() or "outcome" in m.name.lower()]
        self.assertGreaterEqual(len(outcome), 1)
        # The realized outcome must not be point-in-time (it's post-event).
        self.assertFalse(outcome[0].point_in_time_required)
        self.assertIn(
            "leakage",
            outcome[0].leakage_risk.lower(),
        )


class TestZDValidationPlan(unittest.TestCase):
    def test_validation_plan_lists_existing_tests(self):
        oor = _candidate_oor_result()
        result = generate_zd_candidate(oor)

        plan = result.candidate.validation_plan
        plan_text = " ".join(plan).lower()
        self.assertIn("ablation", plan_text)
        self.assertIn("necessity", plan_text)
        self.assertIn("stability", plan_text)
        self.assertIn("discrimination", plan_text)

    def test_candidate_does_not_claim_causal_status(self):
        """The spec must not contain a CausalStatus or CandidateResult."""
        oor = _candidate_oor_result()
        result = generate_zd_candidate(oor)

        candidate = result.candidate
        # No causal-status field.
        self.assertFalse(hasattr(candidate, "causal_status"))
        self.assertFalse(hasattr(candidate, "score"))
        self.assertFalse(hasattr(candidate, "candidate_result"))

    def test_candidate_status_is_proposed_not_confirmed(self):
        oor = _candidate_oor_result()
        result = generate_zd_candidate(oor)

        self.assertEqual(result.candidate.status, ZDProposalStatus.PROPOSED)
        self.assertNotEqual(result.candidate.status, "confirmed")
        self.assertNotEqual(result.candidate.status, "supported")


class TestZDNoPilotInvocation(unittest.TestCase):
    def test_zd_generation_does_not_import_pilot_or_gate(self):
        """The module must not import the pilot or causal-status gate."""
        import cvr30.zd_generation as zd_module

        # Check that the module's namespace does not reference pilot or gate.
        module_attrs = dir(zd_module)
        self.assertNotIn("run_candidate_pilot", module_attrs)
        self.assertNotIn("causal_status_gate", module_attrs)
        self.assertNotIn("PilotReport", module_attrs)
        self.assertNotIn("GateThresholds", module_attrs)
        self.assertNotIn("pilot", module_attrs)
        self.assertNotIn("gate", module_attrs)

        # Check that zd_generation does not transitively import pilot or gate
        # by verifying its direct dependencies.
        import importlib
        spec = importlib.util.find_spec("cvr30.zd_generation")
        self.assertIsNotNone(spec)
        # The module file should not contain import statements for pilot or gate.
        with open(spec.origin) as f:
            source = f.read()
        # Check for actual import statements (not docstring mentions).
        import_lines = [
            line.strip() for line in source.splitlines()
            if line.strip().startswith("from .pilot")
            or line.strip().startswith("from .gate")
            or line.strip().startswith("import cvr30.pilot")
            or line.strip().startswith("import cvr30.gate")
        ]
        self.assertEqual(import_lines, [],
                         f"zd_generation.py should not import pilot or gate: {import_lines}")

    def test_pilot_candidate_id_returns_id_without_running_pilot(self):
        oor = _candidate_oor_result()
        result = generate_zd_candidate(oor)

        cid = pilot_candidate_id(result)
        self.assertEqual(cid, "Z_D")

    def test_pilot_candidate_id_none_for_not_eligible(self):
        oor = _not_eligible_oor_result()
        result = generate_zd_candidate(oor)

        self.assertIsNone(pilot_candidate_id(result))


class TestZDStrategyInjection(unittest.TestCase):
    def test_custom_strategy_generates_candidate(self):
        oor = _candidate_oor_result()

        def custom_strategy(oor_result: OORGateResult) -> ZDCandidateSpec:
            return ZDCandidateSpec(
                candidate_id="custom_ZD",
                label="custom hypothesis",
                hypothesis="A custom variable explains the residual.",
                source_signature=oor_result.signature,
                source_constraint_id=oor_result.constraint_id,
                required_measurements=(
                    ZDMeasurementRequirement(
                        name="custom_measurement",
                        description="A custom measurement.",
                    ),
                ),
            )

        result = generate_zd_candidate_with_strategy(oor, custom_strategy)

        self.assertEqual(result.status, ZDProposalStatus.PROPOSED)
        self.assertEqual(result.candidate.candidate_id, "custom_ZD")
        self.assertEqual(len(result.candidate.required_measurements), 1)

    def test_strategy_not_invoked_when_not_eligible(self):
        oor = _not_eligible_oor_result()

        def strategy(oor_result: OORGateResult) -> ZDCandidateSpec:
            raise AssertionError("Strategy should not be called when not eligible.")

        result = generate_zd_candidate_with_strategy(oor, strategy)
        self.assertEqual(result.status, ZDProposalStatus.NOT_ELIGIBLE)
        self.assertIsNone(result.candidate)


class TestZDEndToEndIntegration(unittest.TestCase):
    """Full ModelHistory → OOR gate → Z_D generation chain."""

    def _build_persistent_blind_spot_history(self):
        sig = ErrorSignature(
            kind=ErrorKind.STRUCTURAL,
            target="next_session_return",
            structural_features=("event_relation",),
            direction=-1,
        )
        failed_accommodation = AccommodationRecord(
            generation_id="M2",
            signature=sig,
            accommodation_type="structural",
            prospective_improvement=0.0,
            status="failed",
        )
        generations = [
            ModelGeneration("M0", None, 0.50, ((sig, 1.0),)),
            ModelGeneration("M1", "M0", 0.70, ((sig, 0.9),)),
            ModelGeneration("M2", "M1", 0.80, ((sig, 0.85),), (failed_accommodation,)),
            ModelGeneration("M3", "M2", 0.84, ((sig, 0.83),)),
        ]
        history = ModelHistory()
        for g in generations:
            history.append(g)
        return history, sig

    def test_full_chain_history_to_zd_candidate(self):
        history, sig = self._build_persistent_blind_spot_history()

        assessments = history.assess(dominant_families=[sig])
        self.assertEqual(
            assessments[sig].status, DiagnosticStatus.PERSISTENT_BLIND_SPOT
        )

        oor_results = review_history_for_oor(
            history.trajectories(),
            assessments,
            independent_constraints={sig: True},
            constraint_ids={sig: "IC-E2E"},
        )

        self.assertEqual(len(oor_results), 1)
        self.assertTrue(oor_results[0].eligible_for_zd_generation)

        zd_result = generate_zd_candidate(oor_results[0])

        self.assertEqual(zd_result.status, ZDProposalStatus.PROPOSED)
        self.assertIsNotNone(zd_result.candidate)
        self.assertEqual(zd_result.candidate.candidate_id, "Z_D")
        self.assertEqual(zd_result.candidate.source_constraint_id, "IC-E2E")
        self.assertEqual(
            zd_result.candidate.source_signature, sig
        )
        self.assertTrue(
            zd_result.candidate.metadata["independent_constraint"]
        )

    def test_full_chain_without_constraint_does_not_generate_zd(self):
        history, sig = self._build_persistent_blind_spot_history()

        assessments = history.assess(dominant_families=[sig])

        oor_results = review_history_for_oor(
            history.trajectories(),
            assessments,
            independent_constraints={},  # no constraint
        )

        self.assertEqual(len(oor_results), 1)
        self.assertFalse(oor_results[0].eligible_for_zd_generation)

        zd_result = generate_zd_candidate(oor_results[0])
        self.assertEqual(zd_result.status, ZDProposalStatus.NOT_ELIGIBLE)
        self.assertIsNone(zd_result.candidate)


if __name__ == "__main__":
    unittest.main()
